<template>
	<view>

		<view class="from">
			<view class="case">只需一步，轻松赚钱</view>
			<view class="box">
				<view class="text">合伙人全称：</view>
				<input type="text" v-model="name" placeholder="个人的真实姓名或公司全称" />
			</view>
			<view class="box">
				<view class="text">联系电话：</view>
				<input type="text" v-model="phone" placeholder="输入手机号" />
				<button @click="getCode">
					{{!codeTime?'获取验证码':codeTime+'s'}}
				</button>
			</view>
			<view class="box">
				<view class="text">验证码：</view>
				<input type="text" placeholder="请输入验证码" />
			</view>
			<!-- <view class="box">
				<view class="text">推荐码：</view>
				<input type="text" placeholder="输入推荐码" />
			</view> -->

			<view class="box">
				<view class="text">选择创业地区：</view>
				<view class="city-site"  @tap="chooseCity">
					{{ address=='' ?   '请选择地点' : address}}
				</view>
				<mpvue-city-picker :themeColor="themeColor" ref="mpvueCityPicker" :pickerValueDefault="cityPickerValue" @onCancel="onCancel"
				 @onConfirm="onConfirm"></mpvue-city-picker>
				
				
			</view>
			
			<view class="box" @click="openSkill">
				<view class="text">合伙人级别：</view>
				<view class="content">{{rank==''? '选择合伙人的级别':rank}}</view>
				<image src="../../../static/image/you.png"></image>
			</view>
		</view>



		<view class="submit" @click="tojgrz2">下一步</view>



	<!-- 弹框 -->
		<view class="skill" v-if="showSkill" @click="closeSkill">
			<view class="skil" @click.stop="stop">
				<view class="skil-top">
					<text @click="closeSkill">取消</text>
					<text @click="affirm">确认</text>
				</view>
				<view class="skil-box">
					<radio-group @change="choose">
						<view class="rank" v-for="(item,index) in arrRank" :key="index">
							<view class="name">
							<radio color="#FF8A00" :value="String(item.id)"></radio>
							<text>{{item.text}}</text>
							</view>
							<text class="detail">点击查看权益详情</text>
						</view>
					</radio-group>
				</view>
			</view>
		</view>



	</view>
</template>

<script>
	import mpvueCityPicker from '../../../components/mpvue-citypicker/mpvueCityPicker.vue';
	import {postHhr,postHhrZf} from '../../../api/api.js';
	export default {
		components: {
			mpvueCityPicker
		},
		data() {
			return {
				name:'',
				phone:'',
				address: '',
				cityPickerValue: [0, 0, 0],
				themeColor: '#007AFF',
				province:"",
				city:"",
				district:"",
				codeTime: 0,
				showSkill:false,
				arrRank:[
					{
						id:1,
						text:"联合合伙人",
					},
					{
						id:2,
						text:"城市合伙人",
					},{
						id:3,
						text:"创客合伙人",
					}
				],
				rank:'',
			}
		},
		onLoad(options) {


		},
		methods: {
			
			// 提交
			tojgrz2(){
				let self = this
				postHhr({
					province: self.province,
					city: self.city,
					district: self.district,
					link_user:self.name,
					link_tel:self.phone
				}).then(res=>{
					console.log(res)
					uni.showToast({
						title:res.data.msg,
						duration:1500,
						icon:"none"
					})
					if(res.data.code==1){
						setTimeout(function() {
							postHhrZf({}).then(re=>{
								console.log(re)
								uni.requestPayment({
									timeStamp: ""+re.data.data.timeStamp+"",
									nonceStr: re.data.data.nonceStr,
									package: re.data.data.package,
									signType: 'MD5',
									paySign: re.data.data.sign,
									success (res) {
											 console.log(res)
										  },
										  fail (res) {
											  console.log(res)
									  }
								})
							})
						}, 1000);
					}
				})
			},
			
			
			
			
			
			
			// 获取选择的地区
			onCancel(e) {
				console.log(e)
			},
			chooseCity() {
				this.$refs.mpvueCityPicker.show()
			},
			onConfirm(e) {
				
				this.cityPickerValue = e.value;
				var address = e.label.split("-")
				
				this.province=address[0]
				this.city=address[1]
				this.district=address[2]
				this.address = address.map(i => i).join(",");
				
			},
			
			
			
			
			
			
			
			getCode() {
				if (this.codeTime > 0) {
					uni.showToast({
						title: '不能重复获取',
						icon: "none"
					});
					return;
				} else {
					this.codeTime = 60
					let timer = setInterval(() => {
						this.codeTime--;
						if (this.codeTime < 1) {
							clearInterval(timer);
							this.codeTime = 0
						}
					}, 1000)
				}
			},

			// 弹框
			closeSkill() {
				this.showSkill = false;
			},
			stop() {},
			openSkill() {
				this.showSkill = true
			},
			choose(e){
				
				var id=e.detail.value
				for(var i=0;i<this.arrRank.length;i++){
					if(id==this.arrRank[i].id){
						this.rank=this.arrRank[i].text
					}
				}
			},
			affirm(){
				this.closeSkill()
			}

		}
	}
</script>

<style scoped>
	@import './hhrrz.css';
</style>
