<template>
	<!-- 推荐好友 -->
	<view>
		<view class="head">
			<view class="imgs">
				<image :src="head"></image>
			</view>
		</view>
		
		<view class="box">
			<text class="name">{{name}}</text>
			<view class="num">已推荐<text>{{num}}</text>人</view>
			<image :src="erwema"></image>
			<view class="submit" @click="submit">保存二维码</view>
			
			
			<!-- 推荐的人 -->
			<view class="person">
				<view class="case" v-for="(item,id) in list" :key="id">
					<image :src="item.avatar"></image>
					<text>{{item.nickname}}</text>
					<text>{{item.add_time_y}}</text>
				</view>
			</view>
		</view>
		
		
		
	</view>
</template>

<script>
	import {getUser,getErweima} from '../../../api/api.js';
	export default {
		data() {
			return {
				head:'',
				name:'',
				erwema:'',
				list:[],
				num:''
			}
		},
		onShow() {
			
			this.getImg();
		},
		methods: {
			
			// 获取二维码
			getImg(){
				getErweima({
					
				}).then(res=>{
					console.log(res)
					this.erwema=res.data.data.litpic
					this.head=res.data.data.avatar
					this.list=res.data.data.list
					this.name=res.data.data.username
					this.num=res.data.data.num
				})
			},
			// 保存二维码
			submit(){
				let self =this
				uni.showModal({
				    title: '保存',
				    content: '保存二维码到相册',
				    success: function (res) {
				        if (res.confirm) {
				            uni.downloadFile({
				            	url:self.erwema,
				            	 success: (res) => {
				            	        if (res.statusCode === 200) {
				            	            uni.showToast({
				            	            	title:"保存成功",
												duration:1500,
												icon:"none"
				            	            })
				            	        }
				            	    }
				            })
				        } else if (res.cancel) {
				            
				        }
				    }
				});
				
			},
			
		}
	}
</script>

<style scoped>
@import './tjhy.css';
</style>
