<template>
	<view>
		<view class="first" v-if="showFirst==0">
			<view class="from">
				<view class="case">还需二步，轻松接单</view>
				<view class="box">
					<view class="text">姓名：</view>
					<input type="text" v-model="from.name" placeholder="请输入真实姓名" />
				</view>
				<view class="box">
					<view class="text">联系电话：</view>
					<input type="text" v-model="from.phone" placeholder="输入您的联系方式" />
				</view>
				<view class="box">
					<view class="text">省市区：</view>
					<view class="city-site"  @tap="chooseCity">
						{{ address=='' ?   '请选择地点' : address}}
					</view>
					<mpvue-city-picker :themeColor="themeColor" ref="mpvueCityPicker" :pickerValueDefault="cityPickerValue" @onCancel="onCancel"
					 @onConfirm="onConfirm"></mpvue-city-picker>
				</view>
				<view class="box">
					<view class="text">联系地址：</view>
					<input type="text" v-model="from.site" placeholder="输入现居住地址" />
				</view>
				<!-- <view class="box">
					<view class="text">营业范围：</view>
					<input type="text"  v-model="from.scope" placeholder="输入准确的营业范围" />
				</view> -->
				<view class="boxs" @click="openSkill">
					<view class="text">技能专业：</view>
					<view class="jineng">
						<text v-if="arrSkill==''">请选择您的专业技能</text>
						<text v-else v-for="(item,index) in arrSkill" :key="index">{{item.store_name}},</text>
					</view>
					<image src="../../../static/image/you.png"></image>
				</view>
				<view class="box">
					<view class="text">户籍所在地：</view>
					<input type="text" v-model="from.census" placeholder="请输入户籍所在地" />
				</view>

			</view>

			<view class="rec">
				<view class="rec-top">个人介绍：</view>
				<view class="tear">
					<textarea placeholder="简单介绍下自己"  v-model="from.rec" placeholder-style="fontSize:26rpx"></textarea>
				</view>
			</view>

			<view class="submit" @click="tojgrz2">下一步</view>

		</view>

		<!-- 第二页 -->
		<view class="second" v-if="showFirst==1">
			<view class="from">
				<view class="case">还差1步，即完成填写</view>

				<view class="imgs">
							<view class="picture" v-for="(item,index) in imgList" :key="index" :data-url="imgList[index]">
								<image :src="imgList[index]" mode="aspectFill"></image>
								<view class="del bg-red" @tap.stop="DelImg" :data-index="index">
									<text class='cuIcon-close'></text>
								</view>
							</view>
							<view class="solid" @tap="ChooseImage" v-if="imgList.length<1">
								<text class='cuIcon-cameraadd'></text>
							</view>
							<!-- 反面 -->
							<view class="picture" v-for="(item,index) in imgFm" :key="index" :data-url="imgFm[index]">
								<image :src="imgFm[index]" mode="aspectFill"></image>
								<view class="del bg-red" @tap.stop="DelFmImg" :data-index="index">
									<text class='cuIcon-close'></text>
								</view>
							</view>
							<view class="solid" @tap="ChooseFmImage" v-if="imgFm.length<1">
								<text class='cuIcon-cameraadd'></text>
							</view>
							<text class="remark">1.点击左侧上传身份证正反面</text>

				</view>
				<!-- 从业资格证 -->
				<view class="imgs">
					<view class="picture" v-for="(item,index) in imgZgz" :key="index" :data-url="imgZgz[index]">
						<image :src="imgZgz[index]" mode="aspectFill"></image>
						<view class="del bg-red" @tap.stop="DelZgzImg" :data-index="index">
							<text class='cuIcon-close'></text>
						</view>
					</view>
					<view class="solid" @tap="ChooseZgzImage" v-if="imgZgz.length<1">
						<text class='cuIcon-cameraadd'></text>
					</view>
					<view class="texts">
					<text class="remark">1.点击左侧从业资格证</text>
					<text class="hint">如何获取从业资格证？</text>
					</view>
				</view>
				<!-- 健康证 -->
				<view class="imgs">
					<view class="picture" v-for="(item,index) in imgJkz" :key="index" :data-url="imgJkz[index]">
						<image :src="imgJkz[index]" mode="aspectFill"></image>
						<view class="del bg-red" @tap.stop="DelJkzImg" :data-index="index">
							<text class='cuIcon-close'></text>
						</view>
					</view>
					<view class="solid" @tap="ChooseJkzImage" v-if="imgJkz.length<1">
						<text class='cuIcon-cameraadd'></text>
					</view>
					<view class="texts">
					<text class="remark">1.点击左侧上传健康证</text>
					<text class="hint">健康证如何办理？</text>
					</view>
				</view>
				<!-- 其他证书或荣誉资质 -->
				<view class="imgs">
					<view class="picture" v-for="(item,index) in imgQt" :key="index" :data-url="imgQt[index]">
						<image :src="imgQt[index]" mode="aspectFill"></image>
						<view class="del bg-red" @tap.stop="DelQtImg" :data-index="index">
							<text class='cuIcon-close'></text>
						</view>
					</view>
					<view class="solid" @tap="ChooseQtImage" v-if="imgQt.length<1">
						<text class='cuIcon-cameraadd'></text>
					</view>
					<text class="remark">1.点击左侧上传其他证书或荣誉资质</text>
					
				</view>
			</view>
			<view class="bottom">
				<view @click="toFirst">上一步</view>
				<view @click="submit">提交审核</view>
			</view>
		</view>




		<!-- 弹框 -->
		<view class="skill" v-if="showSkill" @click="closeSkill">
			<view class="skil" @click.stop="stop">
				<view class="skil-top">
					<text @click="closeSkill">取消</text>
					<text @click="affirm">确认</text>
				</view>
				<view class="skil-box">
					<view class="ify-left">
						<scroll-view class="scroll-y" scroll-y>
							<view class="classes" v-for="(item,id) in arrclasses" :key="id" @click="choose(item)" :class="['name',{option:id==choice}]">
								{{item.cate_name}}
							</view>
						</scroll-view>
					</view>
					<view class="ify-right">
						<view class="right-skil" :class="{right_skils:item.is_select==false}" v-for="(item,index) in arrClassCon" :key="index"
						 @click="choseCon(item)">
							{{item.store_name}}
						</view>
					</view>
				</view>
			</view>
		</view>


	</view>
</template>

<script>
	import mpvueCityPicker from '../../../components/mpvue-citypicker/mpvueCityPicker.vue';
	import{getClassify,postJigong} from '../../../api/api.js'
	export default {
		components:{
			mpvueCityPicker
		},
		data() {
			return {
				showSkill: false,
				showFirst: 0,
				choice: 0,
				left_id: '',
				address:'',
				province:'',
				city:'',
				district:'',
				cityPickerValue: [0, 0, 0],
				themeColor: '#007AFF',
				from:{
					site:'',
					name:'',
					phone:'',
					scope:'',  //营业范围
					rec:'',
					census:''
				},
				arrSkill: [], //显示的技能
				arrclasses: [
				],
				jineng_id:'',
				arrClassCon: [],
				// classCon:[],
				// 图片
				// 身份证
				imgList: [],//正面
				zmUrl:'',
				imgFm:[],//反面
				fmUrl:'',
				imgZgz:[],//资格证
				zgzUrl:'',
				imgJkz:[],//健康证
				jkzUrl:'',
				imgQt:[],//其它
				qtUrl:'',
			}
		},
		onLoad(options) {
			// console.log(options)
			
		},
		onShow() {
			this.getClass();
		},
		methods: {
			
			
			
			
			
			
			
			
			// 申请
			submit(){
				let self = this
				postJigong({
					province:self.province,
					city:self.city,
					district:self.district,
					address:self.from.site,
					link_user:self.from.name,
					link_tel:self.from.phone,
					yingyefanwei:self.from.scope,
					gerenjieshao:self.from.rec,
					jinengzhuanye:self.jineng_id,
					huji:self.from.census,
					merchant_name:'',
					idcardz:self.zmUrl,
					idcardf:self.fmUrl,
					charter:self.zgzUrl,
					jiankangz:self.jkzUrl,
					otherz:self.qtUrl
				}).then(res=>{
					console.log(res)
					uni.showToast({
						title:res.data.msg,
						duration:1500,
						icon:"none"
					})
					if(res.data.code==1){
						uni.navigateTo({
							url:"../../../pages/shenhe/shenhe"
						})
					}
				})
			},
			
			// 获取分类
			getClass(){
				getClassify({
				}).then(res=>{
					console.log(res)
					this.arrclasses=res.data.data
					this.arrClassCon=this.arrclasses[this.choice].cate
					this.left_id=this.arrclasses[this.choice].id
				})
				
			},
			
			//点击切换
			choose(item) {
				this.left_id = item.id; //将选择的id保存
				for (var i = 0; i <= this.arrclasses.length - 1; i++) {
					if (item.id == this.arrclasses[i].id) {
						this.arrClassCon = this.arrclasses[i].cate			
						this.choice = i
					}
				}
			},
			// 选择技能
			choseCon(item) {
				console.log(item)
				var self = this
				// var data	= self.arrclasses;
				// for (var i = 0; i < data.length; i++) {
				// 	if (self.left_id == data[i].id) {
						
				// 		for (var j = 0; j <data[i].children.length; j++) {
				// 			if (item.id == data[i].children[j].id) {
				// 				data[i].children[j].is_select = !data[i].children[j].is_select
				// 				console.log(item)
				// 			}
				// 		}
				// 	}
				// }
				
				for(var i = 0;i<self.arrClassCon.length;i++){
					if(item.id==self.arrClassCon[i].id){
						self.arrClassCon[i].is_select=!self.arrClassCon[i].is_select
					}
				}
				
			},
			// 弹框
			closeSkill() {
				this.showSkill = false;
			},
			stop() {},
			openSkill() {
				this.showSkill = true
			},
			// 弹框确认
			affirm() {
				this.arrSkill = []
				// var _this=this
				for (var i = 0; i < this.arrclasses.length; i++) {
					for (var j = 0; j < this.arrclasses[i].cate.length; j++) {
						if (this.arrclasses[i].cate[j].is_select == false) {
							this.arrSkill.push(this.arrclasses[i].cate[j])
							console.log(this.arrSkill)
						}
					}
					
				};
				var id=[]
				for(var i=0;i<this.arrSkill.length;i++){
					id=id.concat(this.arrSkill[i].id)
				}
				this.jineng_id=id.toString()
				
				this.showSkill = false
			},
			
			
			
			// 获取选择的地区
			onCancel(e) {
				console.log(e)
			},
			chooseCity() {
				this.$refs.mpvueCityPicker.show()
			},
			onConfirm(e) {
				
				this.cityPickerValue = e.value;
				var address = e.label.split("-")
				this.province=address[0]
				this.city=address[1]
				this.district=address[2]
				console.log(this.province)
				this.address = address.map(i => i).join(",");
				
			},
			
			
		
			// 下一页
			tojgrz2() {
				this.showFirst = 1
			},
			// 上一页
			toFirst() {
				this.showFirst = 0
			},
			// 身份证
			//正面
			ChooseImage() {
				uni.chooseImage({
					count: 4, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					success: (res) => {
						if (this.imgList.length != 0) {
							this.imgList = this.imgList.concat(res.tempFilePaths)
						} else {
							this.imgList = res.tempFilePaths
						}
						uni.uploadFile({
							url: 'https://sddj.chengzhangxiu.com/api/upload/images',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (res) => {
								console.log(res)
								let analysisImg = JSON.parse(res.data)
								console.log(analysisImg)
								this.zmUrl=analysisImg.data
								console.log(this.zmUrl)
							}
						})
					}
				});
			},

			DelImg(e) {
				uni.showModal({
					title: '删除',
					content: '确定要删除这张照片吗？',
					cancelText: '取消',
					confirmText: '确定',
					success: res => {
						if (res.confirm) {
							this.imgList.splice(e.currentTarget.dataset.index, 1)
						}
					}
				})
			},
			//反面
			ChooseFmImage() {
				uni.chooseImage({
					count: 4, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					success: (res) => {
						if (this.imgFm.length != 0) {
							this.imgFm = this.imgFm.concat(res.tempFilePaths)
						} else {
							this.imgFm = res.tempFilePaths
						}
						uni.uploadFile({
							url: 'https://sddj.chengzhangxiu.com/api/upload/images',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (res) => {
								console.log(res)
								let analysisImg = JSON.parse(res.data)
								console.log(analysisImg)
								this.fmUrl=analysisImg.data
								
							}
						})
					}
				});
			},
			
			DelFmImg(e) {
				uni.showModal({
					title: '删除',
					content: '确定要删除这张照片吗？',
					cancelText: '取消',
					confirmText: '确定',
					success: res => {
						if (res.confirm) {
							this.imgFm.splice(e.currentTarget.dataset.index, 1)
						}
					}
				})
			},
			//资格证
			ChooseZgzImage() {
				uni.chooseImage({
					count: 4, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					success: (res) => {
						if (this.imgZgz.length != 0) {
							this.imgZgz = this.imgZgz.concat(res.tempFilePaths)
						} else {
							this.imgZgz = res.tempFilePaths
						}
						uni.uploadFile({
							url: 'https://sddj.chengzhangxiu.com/api/upload/images',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (res) => {
								console.log(res)
								let analysisImg = JSON.parse(res.data)
								console.log(analysisImg)
								this.zgzUrl=analysisImg.data
								console.log(this.zgzUrl)
							}
						})
					}
				});
			},
			
			DelZgzImg(e) {
				uni.showModal({
					title: '删除',
					content: '确定要删除这张照片吗？',
					cancelText: '取消',
					confirmText: '确定',
					success: res => {
						if (res.confirm) {
							this.imgZgz.splice(e.currentTarget.dataset.index, 1)
						}
					}
				})
			},
			
			//健康证
			ChooseJkzImage() {
				uni.chooseImage({
					count: 4, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					success: (res) => {
						if (this.imgJkz.length != 0) {
							this.imgJkz = this.imgJkz.concat(res.tempFilePaths)
						} else {
							this.imgJkz = res.tempFilePaths
						}
						uni.uploadFile({
							url: 'https://sddj.chengzhangxiu.com/api/upload/images',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (res) => {
								console.log(res)
								let analysisImg = JSON.parse(res.data)
								console.log(analysisImg)
								this.jkzUrl=analysisImg.data
								console.log(this.jkzUrl)
							}
						})
					}
				});
			},
			
			DelJkzImg(e) {
				uni.showModal({
					title: '删除',
					content: '确定要删除这张照片吗？',
					cancelText: '取消',
					confirmText: '确定',
					success: res => {
						if (res.confirm) {
							this.imgJkz.splice(e.currentTarget.dataset.index, 1)
						}
					}
				})
			},
			//其它证书或荣誉证书
			ChooseQtImage() {
				uni.chooseImage({
					count: 4, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					success: (res) => {
						if (this.imgQt.length != 0) {
							this.imgQt = this.imgQt.concat(res.tempFilePaths)
						} else {
							this.imgQt = res.tempFilePaths
						}
						uni.uploadFile({
							url: 'https://sddj.chengzhangxiu.com/api/upload/images',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (res) => {
								console.log(res)
								let analysisImg = JSON.parse(res.data)
								console.log(analysisImg)
								this.qtUrl=analysisImg.data
								// console.log(this.mdUrl)
							}
						})
					}
				});
			},
			
			DelQtImg(e) {
				uni.showModal({
					title: '删除',
					content: '确定要删除这张照片吗？',
					cancelText: '取消',
					confirmText: '确定',
					success: res => {
						if (res.confirm) {
							this.imgQt.splice(e.currentTarget.dataset.index, 1)
						}
					}
				})
			},
		}
	}
</script>

<style scoped>
	@import './jgrz.css';
</style>
