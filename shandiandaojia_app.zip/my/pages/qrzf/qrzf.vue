<template>
	<view>
		<view class="box">￥<text>{{price}}</text></view>
		<view class="tpye">
			<radio-group @change="radioChange">
			<view class="case">
				<radio :value="String(0)"></radio>
				<image src="../../../static/icon/zhifubao.png"></image>
				<text>支付宝</text>
			</view>
			<view class="case">
				<radio :value="String(1)"></radio>
				<image src="../../../static/icon/weixin.png"></image>
				<text>微信</text>
			</view>
			</radio-group>
		</view>
		
		<view class="submit" @click="submit">去支付</view>
	</view>
</template>

<script>
	import {getVip} from '../../../api/api.js'
	export default {
		data() {
			return {
				price:'',
				type:'',
				timeStamp:'',
				nonceStr:'',
				package:'',
				paySign:'',
			}
		},
		onLoad(option) {
			console.log(option)
			this.price=option.price
		},
		methods: {
			radioChange(e){
				let self=this;
				var num=e.detail.value;
				if(num==0){
					self.type="alipay"
				}else if(num==1){
					self.type="weixin"
				}
				console.log(self.type)
			},
			submit(){
				let self=this
				getVip({
					type:self.type
				}).then(res=>{
					console.log(res)
					self.timeStamp=res.data.data.timeStamp,
					self.nonceStr=res.data.data.nonceStr,
					self.package=res.data.data.package,
					self.paySign=res.data.data.sign,
					
					self.wxPay();
				})
			},
			// 微信支付
			wxPay(){
				let self = this
				console.log(self.timeStamp);
				console.log(self.nonceStr);
				console.log(self.package);
				console.log(self.paySign);
				uni.requestPayment({
				  timeStamp: ""+self.timeStamp+"",
				  nonceStr: self.nonceStr,
				  package: self.package,
				  signType: 'MD5',
				  paySign: self.paySign,
				  success (res) {
					  console.log(res)
					  uni.navigateTo({
					  	url:"../../../pages/zfjg/zfjg?res="+0
					  })
				  },
				  fail (res) {
					  console.log(res)
					  uni.navigateTo({
					  	url:"../../../pages/zfjg/zfjg?res="+1
					  })
				  }
				})
			},
		}
	}
</script>

<style scoped>
@import './qrzf.css';
</style>
