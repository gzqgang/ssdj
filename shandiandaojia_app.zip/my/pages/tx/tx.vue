<template>
	<!-- 提现 -->
	<view>
		<view class="money">
			<view class="money-top">
				<image src="../../../static/image/yhk.png"></image>
				<text>可提现金额(元)</text>
			</view>
			<view class="sum">
				<text>{{arrmoney.money}}</text>
			</view>
			<view class="sort">
				<view class="cont">
					<text>提现申请中（元）</text>
					<text>{{arrmoney.zhong}}</text>
				</view>
				<view class="cont">
					<text>提现已完成（元）</text>
					<text>{{arrmoney.yi}}</text>
				</view>
			</view>

		</view>
		
		<!-- 选择 -->
		<view class="type">
			<view class="box">
				<view class="name">
					真实姓名:
				</view>
				<view class="text">
					<input type="text" v-model="name" placeholder="请输入姓名"/>
				</view>
				
			</view>
			<view class="box">
				<view class="name">
					账号类型:
				</view>
				<view class="text">
					<picker @change="PickerChange" :value="index" :range="picker">
						<view class="picker">
							{{index>-1?picker[index]:'请选择账号类型'}}
						</view>
					</picker>
				</view>
				<view class="img" @change="PickerChange">
					<image src="../../../static/image/you.png"></image>
				</view>
			</view>
			<view class="box" v-if="index==0">
				<view class="name">
					<text>微信账号：</text>
				</view>
				<view class="text">
					<input type="text" v-model="weixin" placeholder="请输入微信号"/>
				</view>
			</view>
			<view class="box"  v-if="index==1">
				<view class="name">
					<text>支付宝账号：</text>
				</view>
				<view class="text">
					<input type="text" v-model="alipay_code" placeholder="请输入支付宝账号"/>
				</view>
			</view>
		</view>
		
		<!-- 提现金额 -->
		<view class="deposit">
			<view class="deposit-top">
				提现金额
			</view>
			<view class="box">
				<view class="logo">￥</view>
				<view class="input">
					<input type="text" v-model="money" @blur="moneys" placeholder-style="color:#CCCCCC" placeholder="最低提现100元"/>
				</view>
				
			</view>
			
			<view class="title">
				<text>手续费：￥0</text>
				<text @click="all">全部提现</text>
			</view>
			
		</view>
		
		<view class="submit" @click="submit">立即提现</view>
		
		
	</view>
</template>

<script>
	import {getMoney,postMoney} from '../../../api/api.js';
	export default {
		data() {
			return {
				arrmoney:'',
				index:-1,
				picker: ['微信', '支付宝'],
				name:'',
				money:'',
				alipay_code:'',//支付宝账号
				weixin:'',//微信账号
				extract_type:''
				
			}
		},
		onShow() {
			this.getmoney();
		},
		methods: {
			getmoney(){
				getMoney({}).then(res=>{
					console.log(res)
					this.arrmoney=res.data.data
				})
			},
			// 立即提现
			submit(){
				// console.log("1")
				let self = this
				postMoney({
					extract_type:self.extract_type,
					name:self.name,
					money:self.money,
					alipay_code:self.alipay_code,
					weixin:self.weixin
				}).then(res=>{
					console.log(res)
					uni.showToast({
						title:res.data.msg,
						duration:1500,
						icon:"none"
					})
					self.getmoney();
				})
			},
			PickerChange(e) {
				this.index = e.detail.value;
				if(this.index==0){
					this.extract_type="weixin"
				}else if(this.index==1){
					this.extract_type="alipay"
				}
			},
			// 判断不能金额
			moneys(e){
				var sum=e.detail.value;
				if(sum<100){
					uni.showToast({
						title:"最低提现金额不能小于100",
						duration:1500,
						icon:"none"
					})
					this.money=''
				}else if(sum>this.arrmoney.money){
					uni.showToast({
						title:"提现金额不能超过可提现金额",
						duration:1500,
						icon:"none"
					})
					this.money=''
				}
			},
			all(){
				this.money=this.arrmoney.money
			}
		}
	}
</script>

<style scoped> 
 @import './tx.css';
</style>
