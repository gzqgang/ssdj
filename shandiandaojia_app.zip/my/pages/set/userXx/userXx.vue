<template>
	<view>
		<!-- 头像 -->
		<view class="header">
			<view class="left">
				<text>头像</text>
			</view>
			<view class="right">
				<image :src="imgurl+'header.jpg'"></image>
				<image src="../../../../static/image/you.png"></image>
			</view>
		</view>
		<!-- 昵称 -->
		<view class="box">
			<view class="left">
				<text>昵称</text>
			</view>
			<view class="right">
				<text>S351531351</text>
				<image src="../../../../static/image/you.png"></image>
			</view>
		</view>
		<!-- 性别 -->
		<view class="box">
			<view class="left">
				<text>性别</text>
			</view>
			<view class="right">
				<text>男</text>
				<image src="../../../../static/image/you.png"></image>
			</view>
		</view>
		
		<!-- 手机号 -->
		<view class="phone">
			<view class="phone-left">
				<text>手机号码</text>
			</view>
			<view class="right">
				<text>18888888888</text>
				<text>已验证</text>
			</view>
		</view>
		
		<!-- 保存 -->
		<view class="submit">保存</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				imgurl:getApp().globalData.imgUrl
			}
		},
		methods: {
			
		}
	}
</script>

<style scoped>
@import './userXx.css';
</style>
