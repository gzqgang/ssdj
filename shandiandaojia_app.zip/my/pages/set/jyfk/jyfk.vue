<template>
	<!-- 建议反馈 -->
	<view>
		<view class="hint">
			<text>
				我们产品还有许多需要改进的地方，您的反馈和建议对我们非常重要，欢迎您对我们的产品功能或有问题的地方提出反馈或建议，以便我们尽快改进产品和服务
			</text>
		</view>
		<view class="textera">
			<textarea placeholder="请输入您的反馈意见或建议"></textarea>
		</view>
		<view class="phone">
			<text>手机号码</text>
			<input type="number" placeholder="请输入手机号(选填)" />
		</view>
		
		<view class="submit">提交</view>	
			
			
		
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style scoped>
@import './jyfk.css';
</style>
