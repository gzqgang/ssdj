<template>
	<!-- 设置 -->
	<view>
		<view class="box">
			<view class="content" @click="toXx">
				<text>个人资料</text>
				<image src="../../../static/image/you.png"></image>
			</view>
			<view class="content">
				<text>设置密码</text>
				<image src="../../../static/image/you.png"></image>
			</view>
			<view class="content">
				<text>清除缓存</text>
				<image src="../../../static/image/you.png"></image>
			</view>
		</view>
		
		
		<view class="box">
			<view class="content" @click="tojyfk">
				<text>建议反馈</text>
				<image src="../../../static/image/you.png"></image>
			</view>
			<view class="content" @click="totszx">
				<text>投诉中心</text>
				<image src="../../../static/image/you.png"></image>
			</view>
			<view class="content" @click="tobzzx">
				<text>帮助中心</text>
				<image src="../../../static/image/you.png"></image>
			</view>
			<view class="content">
				<text>给我们的评价</text>
				<image src="../../../static/image/you.png"></image>
			</view>
			<view class="content">
				<text>用户协议</text>
				<image src="../../../static/image/you.png"></image>
			</view>
			<view class="content">
				<text>隐私政策</text>
				<image src="../../../static/image/you.png"></image>
			</view>
			<view class="content" @click="togywm">
				<text>关于我们</text>
				<image src="../../../static/image/you.png"></image>
			</view>
		</view>
		
		
		<view class="box">
			<view class="content" @click="quite">
				<text>退出登录</text>
				<image src="../../../static/image/you.png"></image>
			</view>
		
		</view>
		
		
	</view>
</template>

<script>
	import {getLogout} from '../../../api/api.js';
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			// 个人信息
			toXx(){
				uni.navigateTo({
					url:"userXx/userXx"
				})
			},
			
			// 建议反馈
			tojyfk(){
				uni.navigateTo({
					url:"jyfk/jyfk"
				})
			},
			// 关于我们
			togywm(){
				uni.navigateTo({
					url:"gywm/gywm"
				})
			},
			// 帮助中心
			tobzzx(){
				uni.navigateTo({
					url:"bzzx/bzzx"
				})
			},
			// 投诉中心
			totszx(){
				uni.navigateTo({
					url:"tszx/tszx"
				})
			},
			
			// 退出登录
			quite(){
				uni.showModal({
				    title: '退出',
				    content: '确定退出登录吗',
				    success: function (res) {
				        if (res.confirm) {
				            getLogout({}).then(res=>{console.log(res)
								if(res.data.code==1){
									uni.showToast({
										title:res.data.msg,
										duration:1500,
										icon:"none"
									})
									setTimeout(function() {
										uni.redirectTo({
											url:"../login/login"
										})
									}, 1500);
									
								}
							})
				        } else if (res.cancel) {
				            
				        }
				    }
				});
			},
		}
	}
</script>

<style scoped>
@import './set.css';
</style>
