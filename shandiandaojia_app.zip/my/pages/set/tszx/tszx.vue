<template>
	<!-- 投诉中心 -->
	<view>
		<view class="end-title">
		　　<view @tap="change(0)" :class="{btna:btnnum == 0}">全部投诉</view>
		  　<view @tap="change(1)" :class="{btna:btnnum == 1}">待处理</view>
		　　<view @tap="change(2)" :class="{btna:btnnum == 2}">已处理</view>
		</view>
		<view class="end-cont" :class="{dis:btnnum == 0}">
		 　　0信息
		</view>
		<view class="end-cont" :class="{dis:btnnum == 1}">
		 　　1信息
		</view>
		<view class="end-cont" :class="{dis:btnnum == 2}">
		  　2信息
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				 btnnum: 0,
				 
			}
		},
		methods: {
			 change(e) {
			      this.btnnum = e
			      
			  }
		}
	}
</script>

<style scoped>
@import './tszx.css';
</style>
