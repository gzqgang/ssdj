<template>
	<!-- 帮助中心 -->
	<view>
		<!-- 消息 -->
		<view class="xiaoxi">
			<image :src="imgurl+'xiaoxi.png'"></image>
		</view>
		
		<view class="cu-chat">
			
			
			<view class="cu-item">
				<view class="cu-avatar radius" style="background-image:url(https://ossweb-img.qq.com/images/lol/web201310/skin/big143004.jpg);"></view>
				<view class="name">小闪(智能客服)</view>
				<view class="main">
					<view class="content shadow">
						<text>亲，小位将在每天9:00-21:00竭诚为您提供在线服务，您也可以直接拨打我们的官方客服电话 952954进行咨询。请问有什么可以帮您的吗？</text>
						<text></text>
					</view>
				</view>
				
			</view>
		
		</view>
		
		<view class="cu-bar foot input" :style="[{bottom:InputBottom+'px'}]">
			<view class="action">
				<text class="cuIcon-sound text-grey"></text>
			</view>
			<input class="solid-bottom" :adjust-position="false" :focus="false" maxlength="300" cursor-spacing="10"
			 @focus="InputFocus" @blur="InputBlur"></input>
			<view class="action">
				<text class="cuIcon-emojifill text-grey"></text>
			</view>
			<button class="cu-btn bg-green shadow">发送</button>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				imgurl:getApp().globalData.imgUrl,
				InputBottom: 0
			}
		},
		methods: {
			InputFocus(e) {
				this.InputBottom = e.detail.height
			},
			InputBlur(e) {
				this.InputBottom = 0
			}
		}
	}
</script>

<style scoped>
@import './bzzx.css';
</style>
