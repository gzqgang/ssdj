<template>
	<!-- 关于我们 -->
	<view>
		<view class="imgs">
			<image :src="imgurl+'logo.png'"></image>
		</view>
		<view class="title">
			<li>
				<view class="text">微信公众号：</view>
				<view class="name">闪电到家</view>
			</li>
			<li>
				<view class="text">商务合作：</view>
				<view class="name">952954
					<image src="../../../../static/image/you.png"></image>
				</view>
			</li>
			<li>
				<view class="text">客服电话：</view>
				<view class="name">952954
				<image src="../../../../static/image/you.png"></image></view>
			</li>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				imgurl:getApp().globalData.imgUrl,
			}
		},
		methods: {
			
		}
	}
</script>

<style scoped>
@import './gywm.css';
</style>
