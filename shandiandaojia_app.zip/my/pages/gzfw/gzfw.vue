<template>
	<!-- 投诉中心 -->
	<view>
		<view class="end-title">
			　　<view @tap="change(0)" :class="{btna:btnnum == 0}">服务</view>
			　<view @tap="change(1)" :class="{btna:btnnum == 1}">技工</view>
			　　
		</view>
		<view class="end-cont" :class="{dis:btnnum == 0}">
			　　<view class="store" v-for="(item,index) in arrserver" :key="index">
				<view class="img">
					<image :src="item.image"></image>
				</view>
				<view class="title">
					<text>{{item.name}}</text>
					<text>{{item.price}}{{item.unit}}</text>
				</view>
				<view class="num">
					<text>取消关注</text>
				</view>
			</view>
		</view>
		<view class="end-cont" :class="{dis:btnnum == 1}">
			<view class="person" v-for="(item,index) in arrartisan" :key="index">
				<view class="person-top">
					<view class="img">
						<image :src="item.image"></image>
					</view>
					<view class="title">
						<view class="name">
							<text>{{item.name}}</text>
							<text>{{item.text}}</text>
						</view>
						<view class="num">工号：{{item.number}}</view>
						<view class="skill">技能：<text v-for="(itme,id) in item.skill">{{itme}},</text></view>
					</view>
				</view>
				<view class="person-bottom">
					<view class="score">
						<image src="../../../static/img/xing.png"></image>
						{{item.score}}分
					</view>
					<view class="comment">评论{{item.comment}}条</view>
				</view>
				
				<view class="box">今日可约</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				btnnum: 1,
				arrserver: [{
						id: 1,
						name: "换锁",
						price: 200,
						unit: "元/次",
						image: getApp().globalData.imgUrl+'zhuangsuo.png'
					},
					{
						id: 1,
						name: "换锁",
						price: 200,
						unit: "元/次",
						image: getApp().globalData.imgUrl+'zhuangsuo.png'
					}
				],
				arrartisan: [{
					id: 1,
					name: "李师傅",
					text: "锁匠师傅",
					number: 8527,
					image:	getApp().globalData.imgUrl+'header.jpg',
					skill: ["开锁", "换锁", '修锁', "汽车开锁", "汽车换锁"],
					score: "4.9",
					comment: 10,
					static:1
				}]
			}
		},
		methods: {
			change(e) {
				this.btnnum = e

			}
		}
	}
</script>

<style scoped>
	@import './gzfw.css';
</style>
