<template>
	<!-- 钱包充值 -->
	<view>
		<view class="head">
			<view class="head-top">
				<image src="../../../static/image/you.png" @click="toback"></image>
				<text>钱包充值</text>
				<text>余额明细</text>
			</view>
			<view class="head-middle">
				<view class="num">
					<view>可用余额</view>
					<view><text>{{money}}</text>元</view>
				</view>
				<view class="tixian" @click="totx">提现</view>
			</view>
			<view class="head-input">
				<input v-model="price" type="text" placeholder="手动输入充值金额" />
			</view>
		</view>
		
		<view class="money">
			<view class="box" v-for="(item,index) in arrLimit" :class="item.id==id? 'border':''" :key="index" @click="choose(item)">
				<text>充值{{parseFloat(item.price)}}送{{parseFloat(item.give_money)}}元</text>
			</view>
			
		</view>
		
		<view class="tpye">
			<radio-group @change="radioChange">
			<view class="case">
				<radio :value="String(0)"></radio>
				<image src="../../../static/icon/zhifubao.png"></image>
				<text>支付宝</text>
			</view>
			<view class="case">
				<radio :value="String(1)"></radio>
				<image src="../../../static/icon/weixin.png"></image>
				<text>微信</text>
			</view>
			</radio-group>
		</view>
		
		
		<view class="title">
			<text v-for="(item,index) in arrText" :key="index">
				{{item}}
			</text>
		</view>
		
		<view class="submit" @click="submit">充值</view>
		
	</view>
</template>

<script>
	import {getRecharge,getUser,postChongzhi} from '../../../api/api.js'
	export default {
		data() {
			return {
				imgurl:getApp().globalData.imgUrl,
				arrLimit:[],
				arrText:[],
				price:'',
				id:'',
				type:'',
				money:'',
				timeStamp:'',
				nonceStr:'',
				package:'',
				paySign:'',
			}
		},
		onShow() {
			this.getLimit();
			this.my();
		},
		methods: {
			// 个人中心
			my(){
				getUser({}).then(res=>{
					// console.log(res,"个人信息")
					this.money=res.data.data.now_money
				})
			},
			// 获取充值额度的选择
			getLimit(){
				getRecharge({}).then(res=>{
					// console.log(res)
					this.arrLimit=res.data.data.recharge_quota
					this.arrText=res.data.data.recharge_attention
				})
				
			},
			choose(item){
				this.id=item.id
			},
			radioChange(e){
				
				let self=this;
				var num=e.detail.value;
				if(num==0){
					self.type="alipay"
				}else if(num==1){
					self.type="weixin"
				}
				console.log(self.type)
			},
			
			
			// 充值
			submit(){
				let self = this;
				postChongzhi({
					type:self.type,
					money:self.price,
					quota:self.id
				}).then(res=>{
					console.log(res)
					self.timeStamp=res.data.data.timeStamp,
					self.nonceStr=res.data.data.nonceStr,
					self.package=res.data.data.package,
					self.paySign=res.data.data.sign,
					
					self.wxPay();
				})
			},
			
			
			// 微信支付
			wxPay(){
				let self = this
				console.log(self.timeStamp);
				console.log(self.nonceStr);
				console.log(self.package);
				console.log(self.paySign);
				uni.requestPayment({
				  timeStamp: ""+self.timeStamp+"",
				  nonceStr: self.nonceStr,
				  package: self.package,
				  signType: 'MD5',
				  paySign: self.paySign,
				  success (res) {
					  console.log(res)
					  uni.navigateTo({
					  	url:"../../../pages/zfjg/zfjg?res="+0
					  })
				  },
				  fail (res) {
					  console.log(res)
					  uni.navigateTo({
					  	url:"../../../pages/zfjg/zfjg?res="+1
					  })
				  }
				})
			},
			
			
			totx(){
				uni.navigateTo({
					url:"../tx/tx"
				})
			},
			toback(){
				uni.navigateBack({
					delta:1
				})
			},
			
		}
	}
</script>

<style scoped>
@import './qbcz.css';
</style>
