<template>
	<view>
		<view class="member" v-for="(item,index) in arrRecord" :key="index">
			<view class="title">
				<text>VIP体验会员</text>
				<text>{{item.add_time_y}}</text>
			</view>
			<view class="price">
				<text>{{item.price}}</text>
			</view>
		</view>
		
	</view>
</template>

<script>
	import {getVipRecord} from '../../../../api/api.js'
	export default {
		data() {
			return {
				arrRecord:[]
			}
		},
		onShow() {
			this.getRecord()
		},
		methods: {
			getRecord(){
				getVipRecord({}).then(res=>{
					console.log(res)
					this.arrRecord=res.data.data
				})
			}
		}
	}
</script>

<style scoped>
@import './gmjl.css';
</style>
