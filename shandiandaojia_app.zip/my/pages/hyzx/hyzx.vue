<template>
	<view>
		<view class="head">
			<view class="head-top">
				<image src="../../../static/img/zuo1.png" @click="toback"></image>
				<text>会员中心</text>
				<text></text>
			</view>
			<view class="head-middle">
				<image class="header" :src="info.avatar"></image>
				<view class="title">
					<text>{{info.nickname}}</text>
					<text @click="togmjl">{{info.e_vip_time!=null? info.e_vip_time_y:'您未开通会员'}} 购买记录></text>
				</view>
				<view class="kaitong" @click="qrzf">立即开通</view>
			</view>
			<view class="save">
				<text>VIP累计已省</text>
				<text>0.00元</text>
			</view>
		</view>
		
		<view class="caption">
			<text>VIP专享折扣</text>
		</view>
		
		<view class="shop-box">
			<view class="shop" v-for="(item,index) in 6" :key="index">
				<image :src="imgurl+'zhuangsuo.png'"></image>
				<view class="titles">
				<text>装锁换锁开锁装锁换锁开锁</text>
				<text>198元/次</text>
				</view>
			</view>
			<view class="more">查看更多 ></view>
		</view>
		
		<view class="caption">
			<text>开通享全部收益</text>
		</view>
		
		
		
		
		<view class="bottom">
			<view class="left">{{price}}/年</view>
			<view class="right" @click="qrzf">立即开通  ></view>
		</view>
	</view>
</template>

<script>
	import {getMember} from '../../../api/api.js';
	export default {
		data() {
			return {
				imgurl:getApp().globalData.imgUrl,
				price:98,
				info:''
			}
		},
		onShow() {
			this.getmember();
		},
		methods: {
			toback(){
				uni.navigateBack({
					delta:1
				})
			},
			qrzf(){
				uni.navigateTo({
					url:"../qrzf/qrzf?price="+this.price
				})
			},
			// 获取会员中心
			getmember(){
				getMember({}).then(res=>{
					console.log(res)
					this.info=res.data.data
					this.price=res.data.data.vip_money
				})
			},
			// 购买记录
			togmjl(){
				uni.navigateTo({
					url:"./gmjl/gmjl"
				})
			}
		}
	}
</script>

<style scoped>
@import './hyzx.css';
</style>
