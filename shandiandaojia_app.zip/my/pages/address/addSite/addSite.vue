<template>
	<view>
		<view class="cu-form-group">
			<view class="title">收货人</view>
			<input placeholder="请填写收货人姓名" name="input" v-model="data.real_name"></input>
		</view>
		<view class="cu-form-group">
			<view class="title">手机号</view>
			<input placeholder="请填写收货人手机号" name="input" v-model="data.phone"></input>

		</view>

		<view class="city">
			<view class="title">省市区</view>
			<view class="city-site"  @tap="chooseCity">
				{{address=='' ?   '请选择地点' :address}}
			</view>
			<mpvue-city-picker :themeColor="themeColor" ref="mpvueCityPicker" :pickerValueDefault="cityPickerValue" @onCancel="onCancel"
			 @onConfirm="onConfirm"></mpvue-city-picker>
			
		</view>


		<view class="detail-site">
			<view class="title">详细地址</view>
			<input placeholder="请填写收货详细地址" name="input" v-model="data.detail"></input>
		</view>
		<view class="default">
			<text>设为默认</text>
			<switch color="#FF9017" :checked="choseSwitch"  @change="isDef"></switch>
		</view>
		<view class="save" @click="saveSite">
			<text>保存</text>
		</view>
	</view>
</template>

<script>
	import mpvueCityPicker from '../../../../components/mpvue-citypicker/mpvueCityPicker.vue';
	
	import {postAddress,getDetail} from '../../../../api/api.js';
	export default {
		components: {
			mpvueCityPicker
		},
		data() {
			return {
				address: '',
				cityPickerValue: [0, 0, 0],
				themeColor: '#007AFF',
				cartlist: [],
				data: {
					real_name: "",
					province:"",
					city:"",
					district:"",
					detail:"",
					phone: "",
					
				},
				choseSwitch:false,
				is_default:0,
				id:'',
			}
		},
		computed: {

		},
		onLoad(option) {
			console.log(option)
			let title = '新增收货地址';
			let self = this;
			if(option.type=='edit'){
				title = '编辑收货地址'
				self.id = option.id
				self.getUserSite();
			}
			uni.setNavigationBarTitle({
				title
			})
		},
		methods: {
			// 获取选择的地区
			onCancel(e) {
				console.log(e)
			},
			chooseCity() {
				this.$refs.mpvueCityPicker.show()
			},
			onConfirm(e) {
				
				this.cityPickerValue = e.value;
				var address = e.label.split("-")
				
				this.data.province=address[0]
				this.data.city=address[1]
				this.data.district=address[2]
				this.address = address.map(i => i).join(",");
				
			},
			
			// 根据id获取地址
			getUserSite(){
				getDetail({
					id:this.id
				}).then(res=>{
					console.log(res)
					this.data=res.data.data
					this.address=res.data.data.province+','+res.data.data.city+','+res.data.data.district
					this.is_default=res.data.data.is_default
					if(this.is_default==1){
						this.choseSwitch=true
					}
				})
			},
			
			// 默认
			isDef(e) {
				
				if(e.detail.value==true){
					this.is_default=1
				}else{
					this.is_default=0
				}
				
			},
			//保存地址
			saveSite(){
				postAddress({
					province:this.data.province,
					city:this.data.city,
					district:this.data.district,
					detail:this.data.detail,
					real_name:this.data.real_name,
					phone:this.data.phone,
					is_default:this.is_default,
					id:this.id
				}).then(res=>{
					console.log(res)
					uni.showToast({
						title:res.data.msg,
						duration:1500,
						icon:"none"
					})
					if(res.data.code==1){
						uni.showToast({
							title:"操作成功",
							duration:1500,
							icon:"none"
						})
						setTimeout(function() {
							uni.navigateTo({
								url:"../address"
							})
						}, 1500);
					}
				})
			}
		}
	}
</script>

<style scoped>
@import './addSite.css'
</style>
