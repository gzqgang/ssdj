<template>
	<view>
		
			<radio-group @change="radioChange">
				<view class="add" v-for="(item,id) in arrsite" :key="id">
					<view class="adds">
						<view class="add-name">
							<text>{{item.real_name}}</text>
							<text>{{item.phone}}</text>
						</view>
						<view class="add-site">
							<!-- <text class="def" v-if="item.is_def==1">默认</text> -->
							<text>{{item.province}},{{item.city}},{{item.district}}</text>
							<text>{{item.detail}}</text>
						</view>
						<view class="set">
							<view class="def">
								<radio :value="String(item.id)" :checked="item.is_default==1" color="#FF8A00"></radio>
								<text v-if="item.is_default==1" class="def_text">已设为默认</text>
								<text v-if="item.is_default!=1">设为默认</text>
							</view>
							<view class="det">
								<text @click="del(item.id)">删除</text>
								<text @click="amend(item.id)">修改</text>
							</view>
						</view>
					</view>
				</view>
			</radio-group>
	

		<view class="add-address" @click="toaddress">
			<text>新增收货地址</text>
		</view>
	</view>
</template>

<script>
	import {getAddress,defaultSet,delSet} from '../../../api/api.js';
	export default {
		data() {
			return {
				arrsite: [
					
				],

			}
		},
		onShow() {
			this.getSite()
		},
		created() {


		},
		methods: {
			// 获取收货地址
			getSite(){
				this.arrsite=[]
				getAddress({}).then(res=>{
					console.log(res)
					this.arrsite=res.data.data
				})
				
				
			},
			
			// 设为默认
			radioChange(e){
				// console.log(e)
				var id = e.detail.value;
				for(var i=0;i<this.arrsite.length;i++){
					this.arrsite[i].is_default=0
					if(this.arrsite[i].id==id){
						this.arrsite[i].is_default=1
					}
				}
				defaultSet({
					id:id
				}).then(res=>{
					console.log(res)
				})
				
			},

			//添加地址
			toaddress() {
				uni.navigateTo({
					url: "./addSite/addSite"
				})
			},
			// 修改
			amend(item){
				var id = item
				var type="edit"
				uni.navigateTo({
					url:"./addSite/addSite?id="+id+"&type="+type
				})
			},
			// 删除
			del(item) {
				let self=this
				uni.showModal({
				    title: '删除',
				    content: '确定删除这条地址吗',
				    success: function (res) {
				        if (res.confirm) {
				            delSet({
				            	id:item
				            }).then(res=>{
				            	console.log(res)
				            	self.getSite();
				            })
							
				        } else if (res.cancel) {
				            console.log('用户点击取消');
				        }
				    }
				});
				
				
			},


		}
	}
</script>

<style scoped>
	@import './address.css';
</style>
