<template>
	<!-- 优惠券 -->
	<view>
		<view class="end-title">
			<view class="left">
				　　<view @tap="change(1)" :class="{btna:btnnum == 1}">
					<text>可使用</text>
				</view>
				　<view @tap="change(2)" :class="{btna:btnnum == 2}">
					<text>已失效</text>
				</view>
			</view>
			<view class="right">
				使用说明
			</view>
		</view>
		<view class="end-cont" v-if="btnnum==1">
		 　　<view class="coupon" v-for="(item,index) in arrcoupon" :key="index">
				<view class="coupon-top">
					<text>¥</text>
					<text>{{item.coupon_price}}</text>
					<view class="name">
						{{item.coupon_title}}
					</view>
				</view>
				<view class="time">
					<text>有效期：{{item._add_time}}至{{item._end_time}}</text>
				</view>
			 <view class="use" @click="tobuy">去使用</view>
			</view>
		 
		</view>

		<view class="end-cont" v-if="btnnum==2">
		 
		</view>

	</view>
</template>

<script>
	import {getCouponUser} from '../../../api/api.js';
	export default {
		data() {
			return {
				btnnum: 1,
				arrcoupon:[
					{
						id:1,
						price:1980,
						name:"下单帝康指纹锁直接抵扣",
						time:"2021-07-01"
					},{
						id:2,
						price:98,
						name:"下单指定商品赠送年会员",
						time:"2021-07-01"
					},{
						id:3,
						price:20,
						name:"下单指定服务直接抵扣20元",
						time:"2021-07-01"
					},{
						id:3,
						price:10,
						name:"下单指定服务直接抵扣20元",
						time:"2021-07-01"
					}
				]
			}
		},
		onShow() {
			this.getcoupon()
		},
		methods: {
			change(e) {
				
				this.btnnum = e
			},
			tobuy(){
				uni.navigateTo({
					url:"../../../pages/buy_lock/buy_lock"
				})
			},
			
			getcoupon(){
				getCouponUser({
					type:this.btnnum
				}).then(res=>{
					console.log(res)
					this.arrcoupon=res.data.data
				})
			}
		}
	}
</script>

<style scoped>
	@import './coupon.css';
</style>
