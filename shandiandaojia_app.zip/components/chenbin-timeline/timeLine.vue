<template>
	<view class="timeline">
		<slot></slot>
	</view>
</template>

<script>
	export default {
		components:{
		}
	}
</script>

<style scoped lang="less">
	.timeline {
		padding: 20rpx;
	}
</style>
