<template>
	<!-- 确认订单 -->
	<view>
		<!-- 地址 -->
		<view class="site">
			<view class="box" @click="openSite">
				<view class="img">
					<image src="../../static/img/jiudian.png"></image>
				</view>
				<view class="title">
					<view class="address">
						<text>服务地址</text>
						<text>{{address.province}}{{address.city}}{{address.district}}</text>
					</view>
					<image src="../../static/image/you.png" mode=""></image>
				</view>
			</view>
			<view class="box">

				<view class="img">
					<image src="../../static/img/shengshiqu.png"></image>
				</view>
				<view class="title">
					{{address.detail}}
				</view>

			</view>
			<view class="box">

				<view class="img">
					<image src="../../static/img/name.png"></image>
				</view>
				<view class="title">
					{{address.real_name}}
				</view>

			</view>
			<view class="box">

				<view class="img">
					<image src="../../static/img/phone.png"></image>
				</view>
				<view class="title">
					<view class="address">
						<text>联系电话</text>
						<text>{{address.phone}}</text>
					</view>

				</view>
			</view>
		</view>

		<!-- 服务时间 -->
		<view class="time">
			<view class="img">
				<image src="../../static/img/Clock2.png"></image>
			</view>
			<view class="title">
				<text>服务时间</text>
				<text @click="showMask">{{time==''? '请选择预约时间': time}}</text>
				<hTimeAlert title="预约时间" subhead="我是副标题" rangeStartTime="00:00:00" rangeEndTime="24:00:00" defaultTime="2020/3/29 18:00:00"
				 intervalTime="30" dayStartIntTime="0" rangeDay="5" :isShow="isShow" :maskHide="maskHide" :rangeType="rangeType"
				 :closeBtn="closeBtn" @closeAlert="handelClose"></hTimeAlert>
			</view>
		</view>

		<!-- 商品 -->
		<view class="shop">
			<view class="store">
				<view class="img">
					<image :src="arrstore.image"></image>
				</view>
				<view class="title">
					<text>{{arrstore.suk}}</text>
					<text>{{arrstore.price}}{{arrstore.unit}}</text>
				</view>
				<view class="num">
					<view class="box">-</view>
						<text>{{num}}</text>
					<view class="box">+</view>
				</view>
			</view>
			<view class="coupon">
				<text>代金券</text>
			</view>
			<view class="tarea">
				<textarea v-model="mark" placeholder="如有特殊要求，请给技工备注留言"></textarea>
			</view>
		</view>

		<view class="price">
			<view class="case">
				<text>服务金额</text>
				<text>{{arrstore.price}}元</text>
			</view>
			<view class="case">
				<text>夜间交通费</text>
				<text>{{jiaotong_money}}元</text>
			</view>
			<view class="case">
				<text>优惠金额</text>
				<text>0元</text>
			</view>
		</view>


		<view class="kong"></view>

		
		<!-- 底部付款 -->
		<view class="bottom">
			<view class="number">
				待支付<text>{{total}}</text>
			</view>
			<view class="submit" @click="submit">立即购买</view>
		</view>
		<!-- 选择地址弹框 -->
		<view class="location" v-if="showSite" @click="closeSite">
			<view class="loca" @click.stop="stop">
				<view class="loca-top">
					<text @click="closeSite">取消</text>
					<text @click="affirm">确认</text>
				</view>
				<view class="loca-cont">
					
					<scroll-view scroll-y="true" class="scroll-y">
						<radio-group style="width: 100%;" @change="radioChange">
						<view class="box" :class="{borders:siteId==item.id}" @click="chooseSite(item)" v-for="(item,index) in arrsite"
						 :key="index">
							<text>{{item.province}}{{item.city}}{{item.district}},{{item.detail}}</text>
							<text>联系人：{{item.real_name}}</text>
							<text>电话：{{item.phone}}</text>
							<view class="checked">
								<radio color="#FF8A00" style="transform: scale(0.7);" :value="String(item.id)" :checked="item.is_default==1"></radio>
								<text>设为默认地址</text>
							</view>
						</view>
							</radio-group>
						<view class="add" @click="addSite">添加新地址</view>
					</scroll-view>
				
				</view>
			</view>
		</view>


	</view>
</template>

<script>
	import hTimeAlert from "@/components/h-time-alert/h-time-alert.vue";
	import {addShopCar,affirmOrder,setOrder,getAttr,getAddress,getDefault,defaultSet} from '../../api/api.js'
	export default {
		components: {
			hTimeAlert
		},
		data() {
			return {
				// 服务时间
				isShow: false,
				maskHide: false,
				closeBtn: false,
				rangeType: false,
				time:'',

				showSite: false,
				siteId: 0,
				address: "",
				arrsite: [{
					
				}, {
					
				}],
				arrstore:{
					// id:1,
					// name:"换锁",
					// image:"../../static/image/huansuo.png",
					// price:100,
					// unit:"元/次",
					
				},
				mark:'',
				total:0,
				price:100,
				jiaotong_money:0,
				
				shopID:'',
				unique:'',
				num:'',
				times:'',
				
			}
		},
		onLoad(option) {
			console.log(option)
			
			this.shopID=option.id
			this.num=option.num
			this.unique=option.unique
		},
		onShow() {
			this.getattr();
			this.getsite();
			this.getdefault();
			
		},
		methods: {
			
			// 获取详情
			getattr(){
				getAttr({
					unique:this.unique
				}).then(res=>{
					console.log(res)
					this.arrstore=res.data.data
					this.getTotal();
				})
			},
			// 获取地址列表
			getsite(){
				getAddress({
				}).then(res=>{
					console.log(res)
					this.arrsite=res.data.data
				})
			},
			
			
			// 获取默认地址
			getdefault(){
				getDefault({
				}).then(res=>{
					console.log(res)
					this.address=res.data.data
				})
				
			},
			
			// 设为默认
			radioChange(e){
				// console.log(e)
				var id = e.detail.value
				defaultSet({
					id:id
				}).then(res=>{
					// console.log(res)
				})
			},
			// 添加新地址
			addSite(){
				uni.navigateTo({
					url:"../../my/pages/address/addSite/addSite"
				})
			},
			
			// 计算总价
			getTotal(){
				this.total=parseInt(this.arrstore.price)+this.jiaotong_money
			},
			
			// 服务时间选择
			showMask() {
				this.isShow = true;
				console.log(this.isShow);
			},

			handelClose(data) {
				console.log(data)
				
				this.time = data.date
				this.isShow = false;
				
				this.times=this.time.substring(9,11)
				if(this.times>=23 || this.times<6){
					this.jiaotong_money=20
				}else{
					this.jiaotong_money=0
				}
				this.getTotal();
				console.log(this.times);
			},
			// 地址选择弹框
			closeSite() {
				this.showSite = false
			},
			openSite() {
				this.showSite = true
			},
			stop() {},
			chooseSite(item) {
				// console.log(item)
				for (var i = 0; i < this.arrsite.length; i++) {
					if (item.id == this.arrsite[i].id) {
						this.siteId = this.arrsite[i].id;
						// this.address=this.arrsite[i]
						// console.log(this.siteId)
					}
				}
			},
			// 选择地址确认
			affirm() {
				for (var i = 0; i < this.arrsite.length; i++) {
					if (this.siteId == this.arrsite[i].id) {
						this.address = this.arrsite[i]
					}
				}
				this.closeSite();
			},
			
			submit(){
				uni.showLoading({
					title:"正在创建订单",
					mask:true
				})
				let self = this;
				addShopCar({
					productId:self.shopID,
					cartNum:self.num,
					uniqueId:self.unique
				}).then(res=>{
					console.log(res)
					uni.hideLoading();
					let cartid=res.data.data.cartId
					self.submitOrder(cartid)
				})
				
				
				
			},
			submitOrder(cartid){
				
				let self =this
				console.log(cartid)
				affirmOrder({
					cartId:cartid
				}).then(res=>{
					
					console.log(res)
					let orderKey =res.data.data.orderKey
					self.setIndent(orderKey)
				})
			},
				
			setIndent(orderKey){
				uni.showLoading({
					title:"正在确认订单",
					mask:true
				})
				let self = this
				setOrder({
					key:orderKey,
					addressId:self.address.id,
					payType:"weixin",
					mark:self.mark,
					from:"routine",
					fuwu_time:self.time,
					jiaotong_money:self.jiaotong_money
				}).then(res=>{
					uni.hideLoading();
					console.log(res)
					uni.showToast({
						title:res.data.msg,
						duration:1500,
						icon:"none"
					})
					if(res.data.status==200){
						setTimeout(function() {
							let orderId=res.data.data.result.orderId;
							let ctype=res.data.data.result.ctype
							uni.navigateTo({
								url:"../zffs/zffs?orderId="+orderId+"&ctype="+ctype
							})
						}, 1500);
						
					}
				})
			}
			
		}
	}
</script>

<style scoped>
	@import './qrdd.css';
</style>
