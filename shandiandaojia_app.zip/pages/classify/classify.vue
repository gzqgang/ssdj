<template>
	<view>
		<view class="head">
			<view class="search">
				<view class="site">
					<image src="../../static/img/dingwei.png" ></image>
					<text>{{city}}</text>
					<image src="../../static/img/sanjiao.png"></image>
				</view>
				<view class="shu"></view>
				<view class="inputs" @click="tosearch">
					<image src="../../static/img/sousuo.png"></image>
					<image src="../../static/img/yuyin.png"></image>
				</view>
			</view>
			<image :src="imgurl+'xiaoxi.png'"></image>
		</view>
		
		
		<view class="body">
		<view class="ify-left">
			<view class="classes" v-for="(item,id) in arrclasses" :key="id" @click="choose(item)" :class="['name',{option:id==choice}]">
				{{item.cate_name}}
			</view>
		</view>
		<view class="ify-right" >
			<view class="bannner">
				  <view class="swiper">
				       <image :src="classCon.pic"></image>
				   </view>
				   <view class="safe">
					   <view class="guard" v-for="(itme,index) in title" :key="index">
						   <image src="../../static/img/bao.png"></image>
						   <text>{{itme}}</text>
					   </view>
				   </view>
			</view>
			
			<view class="sort">
				<text>{{classCon.cate_name}}</text>
				<view class="cont">
					<view class="box" v-for="(item,id) in classCon.cate" :key="id" @click="tospxq(item.id)">
						<image :src="item.image"></image>
						<text>{{item.store_name}}</text>
					</view>
				</view>
			</view>
			
		</view>
		
		
		
		<!-- 底部tabbar -->
		<view class="cu-bar tabbar bg-white">
			<navigator url="../index/index" class="action text-black">
				<image src="../../static/icon/shouye1.png"></image>
				 <text>首页</text>
			</navigator>
			<navigator class="action text-orange">
				<image class="cu_img" src="../../static/icon/fenlei2.png"></image>
				 <text>分类</text>
			</navigator>
			<navigator url="../shanyue/shanyue" class="action text-black add-action">
				<image class="cu_mid" src="../../static/icon/shanyue.png"></image>
				 <text>闪约</text>
			</navigator>
			<navigator url="../indent/indent" class="action text-black">
				<image class="cu_img" src="../../static/icon/dingdan1.png"></image>
				 <text>订单</text>
			</navigator>
			<navigator url="../user/user" class="action text-black">
				<image class="bag" src="../../static/icon/wode1.png"></image>
				 <text>我的</text>
			</navigator>
		</view>
		</view>
	</view>
</template>

<script>
	import {getClassify} from '../../api/api.js';
	export default {
		data() {
			return {
				imgurl:getApp().globalData.imgUrl,
				city:'济南',
				arrclasses:[
					
				],
				
				title:[
					 "标准价报价","快速响应","公安备案"
				],
				
				classCon:{},

				choice:0
			}
		},
		onLoad(option) {
			console.log(option)
			this.getClass(option.type);
			// if(option.choice>=0){
			// 	this.choice=option.choice
			// }else{
			// 	this.choice=0
			// }
			
		},
		onShow() {
			
		},
		methods: {
			
			
			// 获取分类
			getClass(type){
				getClassify({
				}).then(res=>{
					console.log(res)
					this.arrclasses=res.data.data
					this.classCon=this.arrclasses[this.choice]
					
					this.xuanzhong(type)
				})
				
			},
			xuanzhong(type){
				// console.log("111")
				for(var i=0;i<this.arrclasses.length;i++){
					if(type==this.arrclasses[i].id){
						// console.log("111")
						this.classCon=this.arrclasses[i]
						this.choice=i	
					}
				}
			},
			//点击切换
			choose(item){
				for(var i=0;i<=this.arrclasses.length-1;i++){
					if(item.id==this.arrclasses[i].id){
						this.classCon=this.arrclasses[i]
						this.choice=i	
					}
				}
			},
			// 搜索
			tosearch(){
				uni.navigateTo({
					url:"../../other/pages/search/search"
				})
			},
			// 详情
			tospxq(id){
				uni.navigateTo({
					url:"../spxq/spxq?id="+id
				})
			}
		}
	}
</script>

<style scoped>
@import './classify';
</style>
