<template>
	<view>
		
		
		<view class="end-title">
		　　<view @tap="change(0)" :class="{btna:btnnum == 0}">
				<text>全部</text>
			</view>
		  　<view @tap="change(1)" :class="{btna:btnnum == 1}">
			 	<text>发布中</text>
			</view>
		　　<view @tap="change(2)" :class="{btna:btnnum == 2}">
				<text>已取消</text>
			</view>
			<view @tap="change(3)" :class="{btna:btnnum == 3}">
				<text>已完成</text>
			</view>
		
		</view>
		<view class="end-cont" :class="{dis:btnnum == 0}">
			<!-- 如果为空 -->
			<view class="empty">
				<text>暂无任何需求</text>
			</view>
			
			
			
			
			
			<!--  -->
		</view>
		<view class="end-cont" :class="{dis:btnnum == 1}">
		 　　
		</view>
		<view class="end-cont" :class="{dis:btnnum == 2}">
		  　
		</view>
		
		<view class="issue">
			<image src="../../static/icon/shanyue.png" @click="toYysb"></image>
			<text>免费发布需求，让技工主动来约</text>
		</view>
		
		
		
		
		
		
		
		
		<!-- 底部tabbar -->
		<view class="cu-bar tabbar bg-white">
			<navigator url="../index/index" class="action text-black">
				<image src="../../static/icon/shouye1.png"></image>
				 <text>首页</text>
			</navigator>
			<navigator url="../classify/classify" class="action text-black">
				<image class="cu_img" src="../../static/icon/fenlei1.png"></image>
				 <text>分类</text>
			</navigator>
			<navigator class="action text-green add-action">
				<image class="cu_mid" src="../../static/icon/shanyue.png"></image>
				 <text>闪约</text>
			</navigator>
			<navigator url="../indent/indent" class="action text-black">
				<image class="cu_img" src="../../static/icon/dingdan1.png"></image>
				 <text>订单</text>
			</navigator>
			<navigator url="../user/user" class="action text-black">
				<image class="bag" src="../../static/icon/wode1.png"></image>
				 <text>我的</text>
			</navigator>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {				
				btnnum: 0,
				arrIndent:[],
			}
		},
		onLoad() {
			var a = document.getElementsByClassName('uni-page-head-hd')[0]
			a.style.display = 'none';
			
		},
		methods: {
			change(e) {
			      this.btnnum = e
			  },
			  // 语音识别
			  toYysb(){
				  uni.navigateTo({
				  	url:"../yysb/yysb"
				  })
			  }
		}
	}
</script>

<style scoped>
@import './shangyue.css';
</style>
