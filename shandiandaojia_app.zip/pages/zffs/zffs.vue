<template>
	<!-- 支付方式 -->
	<view>
		<view class="type">
			<view class="box">
				<text>订单编号</text>
				<text>{{orderId}}</text>
			</view>
			<view class="box">
				<text>订单金额</text>
				<text class="num">￥{{price}}</text>
			</view>
		</view>
		
		<view class="case" @click="wxPay">
			<view class="type">
				<image src="../../static/icon/weixin.png"></image>
				<text>微信购买</text>
			</view>
			<view class="you">
				<image src="../../static/image/you.png"></image>
			</view>
		</view>
		
		<!-- <view class="case">
			<view class="type">
				<image src="../../static/icon/zhifubao.png"></image>
				<text>支付宝</text>
			</view>
			<view class="you">
				<image src="../../static/image/you.png"></image>
			</view>
		</view> -->
		
		
	</view>
</template>

<script>
	import {getOrderDetail,getFuwuDetail} from '../../api/api.js';
	export default {
		data() {
			return {
				orderId:'',
				timeStamp:'',//时间戳
				price:'',
				nonceStr:'',//随机字符串
				package:'',//订单详情扩展字符串
				signType:'MD5',//签名方式
				paySign:'',//签名
				ctype:'',
			}
		},
		onLoad(option) {
			console.log(option)

			this.orderId=option.orderId;
			this.ctype=option.ctype;
	
			
		},
		onShow() {
			this.getDetail();
		},
		methods: {
			// 获取订单详情
			getDetail(){
				if(this.ctype=='fuwu'){
					getFuwuDetail({
						order_id:this.orderId
					}).then(res=>{
						console.log(res)
						var result=res.data.data
						this.price=result.pay_price;
						this.nonceStr=result.nonceStr;
						this.package=result.package;
						this.paySign=result.paySign;
						this.timeStamp=result.timestamp;
					})
				}else{
					getOrderDetail({
						order_id:this.orderId
					}).then(res=>{
						console.log(res)
						var result=res.data.data
						this.price=result.pay_price;
						this.nonceStr=result.nonceStr;
						this.package=result.package;
						this.paySign=result.paySign;
						this.timeStamp=result.timestamp;
					})
				}
			
			},
			
			// 微信支付
			wxPay(){
				let self = this
				console.log(self.timeStamp);
				console.log(self.nonceStr);
				console.log(self.package);
				console.log(self.paySign);
				uni.requestPayment({
				  timeStamp: ""+self.timeStamp+"",
				  nonceStr: self.nonceStr,
				  package: self.package,
				  signType: 'MD5',
				  paySign: self.paySign,
				  success (res) {
					  console.log(res)
					  uni.navigateTo({
					  	url:"../zfjg/zfjg?res="+0
					  })
				  },
				  fail (res) {
					  console.log(res)
					  uni.navigateTo({
					  	url:"../zfjg/zfjg?res="+1
					  })
				  }
				})
			},
			
		}
	}
</script>

<style scoped>
@import './zffs.css';
</style>
