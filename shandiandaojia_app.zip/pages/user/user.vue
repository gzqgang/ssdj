<template>
	<view class="body">
		<view class="head">
			<view class="set">
				<view class="img">
					<image :src="imgurl+'shezhi.png'" @click="toset"></image>
					<image :src="imgurl+'xiaoxi.png'"></image>
				</view>
			</view>
			<view class="portrait" @click="togrzx">
				<image :src="infor.avatar"></image>
				<text>{{infor.nickname}}</text>
			</view>
			<!-- 关注服务 优惠卷 保修卡 -->
			<view class="mess">
				<view class="box" @click="togzfw">
					<text>{{infor.fuwu}}</text>
					<text>关注服务</text>
				</view>
				<view class="box" @click="tocoupon">
					<text>{{infor.youhuiquan}}</text>
					<text class="shu">优惠券</text>
				</view>
				<!-- <view class="box">
					<text>0</text>
					<text class="shu">保修卡</text>
				</view> -->
				<view class="box" @click="toqbcz">
					<text>{{infor.now_money}}</text>
					<text class="shu">余额 <text>充值</text></text>
				</view>
			</view>
			<!-- 会员 -->
			<view class="member" @click="tohyzx">
				<view class="member_left">
					<view class="image">
						<image :src="imgurl+'huiyuan.png'"></image>
						<text>闪电会员</text>
					</view>
					<view class="title">
						<text>每月5次88折，享多种会员特权</text>
					</view>
				</view>
				<view class="member_right">
					<view class="discount">
						<text>立享88折></text>
					</view>
				</view>
			</view>
			
		</view>
		
		<!-- 我的订单 -->
		<view class="myIndent">
			<view class="indent-top" @click="toindent">
				<view class="indent-left">
					<text>我的订单</text>
				</view>
				<image src="../../static/image/you.png"></image>
			</view>
		</view>
			<!-- 待付款 待发货 -->
			<view class="indent-bottom">
				<ul>
					<li>
						<image :src="imgurl+'daifukuan.png'"></image>
						<text>待付款</text>
					</li>
					<li>
						<image :src="imgurl+'daijiedan.png'"></image>
						<text>待接单</text>
					</li>
					<li>
						<image :src="imgurl+'daishangmen.png'"></image>
						<text>待上门</text>
					</li>
					<li>
						<image :src="imgurl+'daipingjia.png'"></image>
						<text>待评价</text>
					</li>
					<li >
						<image :src="imgurl+'fanxiu.png'"></image>
						<text>返修/售后</text>
					</li>
				</ul>
			</view>

		<!-- 我的服务 -->
		<view class="myServe">
			<view class="myServe-top">
					<text>我的服务</text>
			</view>
			</view>
			<!-- 钱包-->
			<view class="indents-bottom">
				<ul>
					<li @click="tosite">
						<image :src="imgurl+'dizhi.png'"></image>
						<text>我的地址</text>
					</li>
					<li @click="totjhy">
						<image  :src="imgurl+'tuijian.png'"></image>
						<text>推荐好友</text>
					</li>
					<li>
						<image :src="imgurl+'pingjia.png'"></image>
						<text>我的评价</text>
					</li>
					<li @click="tomyxq">
						<image :src="imgurl+'xiuqiu.png'"></image>
						<text>我的需求</text>
					</li>
				</ul>
				<ul>
					<li @click="tojgrz">
						<image  class="smails" :src="imgurl+'jigong.png'"></image>
						<text>技工入驻</text>
					</li>
					<li @click="tokefu">
						<image :src="imgurl+'bangzhu.png'"></image>
						<text>帮助与客服</text>
					</li>
					<li>
						<image class="smail" :src="imgurl+'shangwu.png'"></image>
						<text>商务合作</text>
					</li>
					<li @click="tohhrrz">
						<image :src="imgurl+'hehuoren.png'"></image>
						<text>合伙人入驻</text>
					</li>
					
				</ul>
				
			</view>
			
			<view class="history">
				<view class="history-top">
						<text>浏览历史</text>
				</view>
				
			</view>
			
			
		<!-- 推荐 -->
		<view class="rec">
			<view class="rec-top">
				<image src="../../static/image/rec.png"></image>
			</view>
			
			<view class="recs">
				<view class="mend" v-for="(item,index) in arrNavCont" :key="index">
					<view class="image">
						<image :src="item.image"></image>
					</view>
					<view class="title">
						<text class="name">{{item.store_name}}</text>
						<view class="price">
							<text>￥</text>
							<text>{{item.price}}</text>
						</view>
					</view>
				</view>
			</view>
		</view>
		
		
		
		<view class="kong"></view>
		<!-- 底部tabbar -->
				<view class="cu-bar tabbar bg-white">
					<navigator url="../index/index" class="action text-black">
						<image src="../../static/icon/shouye1.png"></image>
						 <text>首页</text>
					</navigator>
					<navigator url="../classify/classify" class="action text-black">
						<image class="cu_img" src="../../static/icon/fenlei1.png"></image>
						 <text>分类</text>
					</navigator>
					<navigator url="../shanyue/shanyue" class="action text-black add-action">
						<image class="cu_mid" src="../../static/icon/shanyue.png"></image>
						 <text>闪约</text>
					</navigator>
					<navigator url="../indent/indent" class="action text-black">
						<image class="cu_img" src="../../static/icon/dingdan1.png"></image>
						 <text>订单</text>
					</navigator>
					<view  class="action text-orange">
						<image class="bag" src="../../static/icon/wode2.png"></image>
						 <text>我的</text>
					</view>
				</view>
	</view>
</template>

<script>
	import {getUser,getIndexSift} from '../../api/api.js';
	export default {
		data() {
			return {
				imgurl:getApp().globalData.imgUrl,
				arrNavCont:[
				
				],
				page:1,
				infor:'',
			}
		},
		onLoad() {
			
			
		},
		onShow(){
			this.my();
			this.getIndexsift();
		},
		onReachBottom() {
			this.page+=1;
			this.getIndexsift()
		},
		methods: {
			// 获取个人信息
			my(){
				getUser({
				}).then(res=>{
					console.log(res)
					this.infor=res.data.data
					
				})
			},
			// 获取首页下方服务
			getIndexsift(){
				uni.showLoading({
					title:"加载中",
					mask:true
				})
				getIndexSift({
					page:this.page
				}).then(res=>{
					// console.log(res)
					uni.hideLoading()
					this.arrNavCont=this.arrNavCont.concat(res.data.data)
				})
			},
			// 订单
			toindent(){
				uni.navigateTo({
					url:"../indent/indent"
				})
			},
			// 客服
			tokefu(){
				uni.navigateTo({
					url:"../../my/pages/set/bzzx/bzzx"
				})
			},
			// 个人中心
			togrzx(){
				uni.navigateTo({
					url:"../../my/pages/set/userXx/userXx"
				})
			},
			// 优惠券
			tocoupon(){
				uni.navigateTo({
					url:"../../my/pages/coupon/coupon"
				})
			},
			// 我的需求
			tomyxq(){
				uni.navigateTo({
					url:"../myxq/myxq"
				})
			},
			// 地址
			tosite(){
				uni.navigateTo({
					url:"../../my/pages/address/address"
				})
			},
			// 设置
			toset(){
				uni.navigateTo({
					url:"../../my/pages/set/set"
				})
			},
			// 技工入驻选择地址
			tojgrz(){
				uni.navigateTo({
					url:"../../my/pages/jgrz/jgrz"
				})
			},
			//合伙人入驻
			tohhrrz(){
				uni.navigateTo({
					url:"../../my/pages/hhrrz/hhrrz"
				})
			},
			// 推荐好友
			totjhy(){
				uni.navigateTo({
					url:"../../my/pages/tjhy/tjhy"
				})
			},
			// 关注服务
			togzfw(){
				uni.navigateTo({
					url:"../../my/pages/gzfw/gzfw"
				})
			},
			// 钱包充值
			toqbcz(){
				uni.navigateTo({
					url:"../../my/pages/qbcz/qbcz"
				})
			},
			// 会员专享
			tohyzx(){
				uni.navigateTo({
					url:"../../my/pages/hyzx/hyzx"
				})
			}
		}
	}
</script>

<style scoped>
@import './user.css';
</style>

