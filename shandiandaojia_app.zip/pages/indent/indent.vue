<template>
	<view>
		<view class="end-title">
			<scroll-view class="scroll-x" scroll-x="true" scroll-with-animation :scroll-left="scrollLeft">
				　　<view class="end-box" @tap="change(0)" :class="{btna:btnnum == 0}">
					<view>
						<image v-if="btnnum==0" :src="imgurl+'4.png'"></image>
						<image v-else :src="imgurl+'3.png'"></image>
						<text>全部</text>
					</view>
				</view>
				　<view class="end-box" @tap="change(1)" :class="{btna:btnnum == 1}">
					<view>
						<image v-if="btnnum==1" :src="imgurl+'2.png'"></image>
						<image v-else :src="imgurl+'12.png'"></image>
						<text>待付款</text>
					</view>
				</view>
				　　<view class="end-box" @tap="change(2)" :class="{btna:btnnum == 2}">
					<view>
						<image v-if="btnnum==2" :src="imgurl+'6.png'"></image>
						<image v-else :src="imgurl+'5.png'"></image>
						<text>待接单</text>
					</view>
				</view>
				<view class="end-box" @tap="change(3)" :class="{btna:btnnum == 3}">
					<view>
						<image v-if="btnnum==3" :src="imgurl+'daishangmen.png'"></image>
						<image v-else :src="imgurl+'11.png'"></image>
						<text>进行中</text>
					</view>
				</view>
				
				<view class="end-box" @tap="change(5)" :class="{btna:btnnum == 4}">
					<view>
						<image v-if="btnnum==5" :src="imgurl+'10.png'"></image>
						<image v-else :src="imgurl+'9.png'"></image>
						<text>待评价</text>
					</view>
				</view>
				<!-- <view class="end-box" @tap="change(4)" :class="{btna:btnnum == 5}">
					<view>
						<image v-if="btnnum==4" src="../../static/indent/8.png"></image>
						<image v-else src="../../static/indent/7.png"></image>
						<text>已完成</text>
					</view>
				</view> -->
			</scroll-view>
		</view>
		<view class="end-cont" :class="{dis:btnnum == 0}">
			<!-- 如果为空 -->
			<view class="empty" v-if="arrIndent==''">
				<image src="../../static/indent/wu.png"></image>
				<text>暂无订单~</text>
				<text>闪电到家·服务万家</text>
			</view>
			<view class="goods" v-for="(item,id) in arrIndent" :key="id">
				<view class="image"  @click="toxq(item)">
					<image :src="item.cartInfo[0].productInfo.image"></image>
				</view>
				<view class="title"  @click="toxq(item)">
					<view class="name">
						<view>{{item.cartInfo[0].productInfo.store_name}}</view>
						<view class="status">
							<text v-if="item.status==0">待付款</text>
							<text v-if="item.status==1">待接单</text>
							<text v-if="item.status==2">进行中</text>
							<text v-if="item.status==3">待评价</text>
						</view>
					</view>
					<view class="site">服务地址：{{item.user_address}}</view>
					<view class="time">上门时间：{{item.fuwu_time}}</view>
					<view class="number">订单编号：{{item.order_id}}</view>
				</view>
				<view class="bottom">
					<view class="serial"></view>
					<view class="btn">
						<view class="box1" v-if="item.status==0" @click="Cancel(item)">取消订单</view>
						<!-- <view class="box1" v-if="item.status==2 || item.status==3">申请售后</view> -->
						
						<view class="box2" v-if="item.status==1">等待接单...</view>
						
						<view class="box3" v-if="item.status==3">晒评价</view>
						<view class="box3" v-if="item.status==2">确认完成</view>
						<view class="box3" v-if="item.status==0" @click="topay(item)">立即支付</view>
					</view>
				</view>
			</view>

		</view>
		
		<!-- 待付款 -->
		<view class="end-cont" :class="{dis:btnnum == 1}">
			　　
			<view class="empty" v-if="arrIndent==''">
				<image src="../../static/indent/wu.png"></image>
				<text>暂无订单~</text>
				<text>闪电到家·服务万家</text>
			</view>
			<view class="goods" v-for="(item,id) in arrIndent" :key="id">
				<view class="image"  @click="toxq(item)">
					<image :src="item.cartInfo[0].productInfo.image"></image>
				</view>
				<view class="title"  @click="toxq(item)">
					<view class="name">
						<view>{{item.cartInfo[0].productInfo.store_name}}</view>
						<view class="status">
									<text v-if="item.status==0">待付款</text>
								</view>
							</view>
							<view class="site">服务地址：{{item.user_address}}</view>
							<view class="time">上门时间：{{item.fuwu_time}}</view>
							<view class="number">订单编号：{{item.order_id}}</view>
						</view>
						<view class="bottom">
							<view class="serial"></view>
							<view class="btn">
								<view class="box1" v-if="item.status==0 || item.status==1" @click="Cancel(item)">取消订单</view>
								<view class="box3" v-if="item.status==0" @click="topay(item)">立即支付</view>
							</view>
				</view>
			</view>
		</view>
		
		<!-- 待接单 -->
		<view class="end-cont" :class="{dis:btnnum == 2}">
			　	<view class="empty" v-if="arrIndent==''">
				<image src="../../static/indent/wu.png"></image>
				<text>暂无订单~</text>
				<text>闪电到家·服务万家</text>
			</view>
			<view class="goods" v-for="(item,id) in arrIndent" :key="id">
				<view class="image"  @click="toxq(item)">
					<image :src="item.cartInfo[0].productInfo.image"></image>
				</view>
				<view class="title"  @click="toxq(item)">
					<view class="name">
						<view>{{item.cartInfo[0].productInfo.store_name}}</view>
						<view class="status">
									<text v-if="item.status==1">待接单</text>

								</view>
							</view>
							<view class="site">服务地址：{{item.user_address}}</view>
							<view class="time">上门时间：{{item.fuwu_time}}</view>
							<view class="number">订单编号：{{item.order_id}}</view>
						</view>
						<view class="bottom">
							<view class="serial"></view>
							<view class="btn">
								<view class="box1" v-if="item.status==0 || item.status==1">取消订单</view>
								<view class="box2" v-if="item.status==1">等待接单...</view>
							</view>
				</view>
			</view>
		</view>
		
		<!-- 进行中 -->
		<view class="end-cont" :class="{dis:btnnum == 3}">
			　	<view class="empty" v-if="arrIndent==''">
				<image src="../../static/indent/wu.png"></image>
				<text>暂无订单~</text>
				<text>闪电到家·服务万家</text>
			</view>
			<view class="goods" v-for="(item,id) in arrIndent" :key="id">
				<view class="image"  @click="toxq(item)">
					<image :src="item.cartInfo[0].productInfo.image"></image>
				</view>
				<view class="title"  @click="toxq(item)">
					<view class="name">
						<view>{{item.cartInfo[0].productInfo.store_name}}</view>
						<view class="status">
									<text v-if="item.status==2">进行中</text>			
								</view>
							</view>
							<view class="site">服务地址：{{item.user_address}}</view>
							<view class="time">上门时间：{{item.fuwu_time}}</view>
							<view class="number">订单编号：{{item.order_id}}</view>
						</view>
						<view class="bottom">
							<view class="serial"></view>
							<view class="btn">
								
								<view class="box3" v-if="item.status==2">确认完成</view>
							</view>
				</view>
			</view>	
		</view>
		
		
		<!-- 待评价 -->
		<view class="end-cont" :class="{dis:btnnum == 4}">
			　	<view class="empty" v-if="arrIndent==''">
				<image src="../../static/indent/wu.png"></image>
				<text>暂无订单~</text>
				<text>闪电到家·服务万家</text>
			</view>
			<view class="goods" v-for="(item,id) in arrIndent" :key="id">
				<view class="image"  @click="toxq(item)">
					<image :src="item.cartInfo[0].productInfo.image"></image>
				</view>
				<view class="title"  @click="toxq(item)">
					<view class="name">
						<view>{{item.cartInfo[0].productInfo.store_name}}</view>
						<view class="status">
									<text v-if="item.status==3">待评价</text>
								</view>
							</view>
							<view class="site">服务地址：{{item.user_address}}</view>
							<view class="time">上门时间：{{item.fuwu_time}}</view>
							<view class="number">订单编号：{{item.order_id}}</view>
						</view>
						<view class="bottom">
							<view class="serial"></view>
							<view class="btn">			
								<view class="box1" v-if="item.status==3">申请售后</view>								
								<view class="box3" v-if="item.status==3">晒评价</view>
							</view>
				</view>
			</view>
			
			
		</view>




		<!-- 底部tabbar -->
		<view class="cu-bar tabbar bg-white">
			<navigator url="../index/index" class="action text-black">
				<image src="../../static/icon/shouye1.png"></image>
				<text>首页</text>
			</navigator>
			<navigator url="../classify/classify" class="action text-black">
				<image class="cu_img" src="../../static/icon/fenlei1.png"></image>
				<text>分类</text>
			</navigator>
			<navigator url="../shanyue/shanyue" class="action text-black add-action">
				<image class="cu_mid" src="../../static/icon/shanyue.png"></image>
				<text>闪约</text>
			</navigator>
			<navigator class="action text-orange">
				<image class="cu_img" src="../../static/icon/dingdan2.png"></image>
				<text>订单</text>
			</navigator>
			<navigator url="../user/user" class="action text-black">
				<image class="bag" src="../../static/icon/wode1.png"></image>
				<text>我的</text>
			</navigator>
		</view>
	</view>
</template>

<script>
	import {getOrder,postCancel} from '../../api/api.js';
	export default {
		data() {
			return {
				imgurl:getApp().globalData.imgUrl,
				btnnum: 0,
				scrollLeft:0,
				arrIndent: [],
				arrNavCont: [],
				page:1,
			}
		},
		onLoad() {
			var a = document.getElementsByClassName('uni-page-head-hd')[0]
			a.style.display = 'none';
		},
		onReachBottom() {
			this.page+=1;
			this.getIndent();
		},
		onShow() {
			this.arrIndent=[]
			this.getIndent();
		},
		methods: {
			change(e) {
				console.log(e)
				this.btnnum = e;
				this.scrollLeft = (e - 1) * 60
				this.arrIndent=[]
				this.getIndent();
			},
			toxq(item) {
				var orderId = item.order_id;
				var ctype=item.ctype
				uni.navigateTo({
					url:"../ddxq/ddxq?orderId="+orderId+"&ctype="+ctype
				})
			},
			// 立即支付
			topay(item){
				var orderId =item.order_id;
				var ctype=item.ctype
				uni.navigateTo({
					url:"../zffs/zffs?orderId="+orderId+"&ctype="+ctype
				})
			},
			
			
			// 获取订单列表
			getIndent(){
				let self=this
				uni.showLoading({
					title:"加载中",
					mask:true
				})
				getOrder({
					type:self.btnnum,
					page:self.page,
					limit:10
				}).then(res=>{
					console.log(res)
					uni.hideLoading()
					this.arrIndent=this.arrIndent.concat(res.data.data)
				})
			},
			getoder(){
				let self=this
				uni.showLoading({
					title:"加载中",
					mask:true
				})
				getOrder({
					type:self.btnnum,
					page:self.page,
					limit:10
				}).then(res=>{
					console.log(res)
					uni.hideLoading()
					this.arrIndent=res.data.data
				})
			},
			// 取消订单
			Cancel(item){
				let self=this
				uni.showModal({
				    title: '取消订单',
				    content: '确定取消这笔订单吗',
				    success: function (res) {
				        if (res.confirm) {
				            postCancel({
				            	id:item.order_id
				            }).then(res=>{
				            	console.log(res)
								uni.showToast({
									title:res.data.msg,
									duration:1500,
									icon:"none"
								})
				            })
							self.getoder();
				        } else if (res.cancel) {
				            console.log('用户点击取消');
				        }
				    }
				});
				
			}
		}
	}
</script>

<style scoped>
	@import './indent.css';
</style>
