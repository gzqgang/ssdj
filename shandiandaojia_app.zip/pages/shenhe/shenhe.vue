<template>
	<!-- 评价成功 -->
	<view>
		<view class="imgs">
			<image src="../../static/image/pjcg.png"></image>
		</view>
		<view class="title">
			<text>申请成功，审核中</text>
			
		</view>
		
		<view class="submit" @click="toindex">返回首页</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			toindex(){
				uni.redirectTo({
					url:"../index/index"
				})
			}
		}
	}
</script>

<style scoped>
@import './shenhe.css';
</style>
