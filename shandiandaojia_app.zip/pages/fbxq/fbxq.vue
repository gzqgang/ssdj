<template>
	<view>
		<view class="need">
			<textarea :value="value"></textarea>
		</view>
		<view class="need-img">
			<!-- 照片 -->
			<view class="imgs">
				<view class="picture" v-for="(item,index) in imgJkz" :key="index" :data-url="imgJkz[index]">
					<image :src="imgJkz[index]" mode="aspectFill"></image>
					<view class="del bg-red" @tap.stop="DelJkzImg" :data-index="index">
						<text class='cuIcon-close'></text>
					</view>
				</view>
				<view class="solid" @tap="ChooseJkzImage" v-if="imgJkz.length<1">
					<text class='cuIcon-cameraadd'></text>
				</view>
				
			</view>
		</view>
		
		<view class="box">
			<view class="case">
				<view class="text">服务类型</view>
				<view class="title">
					<text>上门安装</text>
					<image src="../../static/image/you.png"></image>
				</view>
			</view>
			<view class="case">
				<view class="text">服务地址</view>
				<view class="title">
					<text>地址地址</text>
					<image src="../../static/image/you.png"></image>
				</view>
			</view>
			<view class="case">
				<view class="text">服务时间</view>
				<view class="title">
					<text>尽快</text>
					<image src="../../static/image/you.png"></image>
				</view>
			</view>
			<view class="case">
				<view class="text">预选要求</view>
				<view class="title">
					<text>不限</text>
					<image src="../../static/image/you.png"></image>
				</view>
			</view>
			<view class="case">
				<view class="text">有效期</view>
				<view class="title">
					<text>24小时</text>
					<image src="../../static/image/you.png"></image>
				</view>
			</view>
		</view>
		
		<!-- 说明 -->
		<view class="explain">您的需求将广播给附近优质f服务人员，意向商家可在有效期内通过站内消息回应您的需求 平台将严格保护您的隐私安全，不会产生来电打扰</view>
		
		
		<!-- 底部立即发布 -->
		<view class="bottom">
			<view class="submit">立即发布</view>
		</view>
		
	</view>
</template>

<script>
	// import {getSiteDe}
	export default {
		data() {
			return {
				value:'123',
				imgJkz:[],//健康证
				jkzUrl:'',
			}
		},
		onLoad(options) {
			
			this.value=options.value;
			console.log(this.value)
		},
		methods: {
			
			//照片
			ChooseJkzImage() {
				uni.chooseImage({
					count: 4, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					success: (res) => {
						if (this.imgJkz.length != 0) {
							this.imgJkz = this.imgJkz.concat(res.tempFilePaths)
						} else {
							this.imgJkz = res.tempFilePaths
						}
						uni.uploadFile({
							url: 'https://sddj.chengzhangxiu.com/api/upload/images',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (res) => {
								console.log(res)
								let analysisImg = JSON.parse(res.data)
								console.log(analysisImg)
								this.jkzUrl=analysisImg.data
								console.log(this.jkzUrl)
							}
						})
					}
				});
			},
			
			DelJkzImg(e) {
				uni.showModal({
					title: '删除',
					content: '确定要删除这张照片吗？',
					cancelText: '取消',
					confirmText: '确定',
					success: res => {
						if (res.confirm) {
							this.imgJkz.splice(e.currentTarget.dataset.index, 1)
						}
					}
				})
			},
			
			
		}
	}
</script>

<style scoped>
@import './fbxq.css';
</style>
