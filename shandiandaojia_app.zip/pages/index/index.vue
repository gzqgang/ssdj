<template>
	<view>
		<view class="content">
			<!-- 搜索 -->
			<view class="head">
				<view class="head-top">
					<view class="site">
						<image src="../../static/img/site.png"></image>
						<text>{{city}}</text>
						<image src="../../static/img/sanjiao1.png"></image>
					</view>
					<image class="head-img" :src="imgurl+'xiaoxi.png'" mode=""></image>
				</view>

				<view class="search">

					<view class="shu"></view>
					<view class="inputs" @click="tosearch" >
						<image src="../../static/img/sousuo.png"></image>
						<input placeholder="水电维修" placeholder-style="color:#BABABA" />
					</view>
				</view>

			</view>

			<!-- 轮播图 -->
			<view class="swiper">
				<swiper autoplay="true"  indicator-active-color="#FF9017">
					<swiper-item v-for="(item,id) in swiper" :key="id">
						<image :src="item.pic"></image>
					</swiper-item>
				</swiper>
			</view>
			<!-- 保障 -->
			<view class="safe">
				<view class="box">
					<image src="../../static/img/bao.png"></image>
					<text>时效保障</text>
				</view>
				<view class="box border">
					<image src="../../static/img/bao.png"></image>
					<text>价格保障</text>
				</view>
				<view class="box border">
					<image src="../../static/img/bao.png"></image>
					<text>服务保障</text>
				</view>
				<view class="box border">
					<image src="../../static/img/bao.png"></image>
					<text>质量保障</text>
				</view>
			</view>

			<!-- 导航 -->
			<view class="navi">
				<swiper indicator-active-color="#FF9017">
					<swiper-item>
						<view class="btn" v-for="(item,index) in nav" :key="index" v-if="index<10" @click="choose(item.type)">
							<image :src="item.pic"></image>
							<text>{{item.name}}</text>
						</view>
					</swiper-item>
					<swiper-item v-if="nav.length>10">
						<view class="btn" v-for="(item,index) in nav" :key="index" v-if="index>=10" @click="choose(item.type)">
							<image :src="item.pic"></image>
							<text>{{item.name}}</text>
						</view>
					</swiper-item>
				</swiper>
			</view>

			<!-- 闪电达 -->
			<view class="case">
				<view class="case-top">
					<text>闪电达</text>
					<text>最快30分钟上门</text>
				</view>
				<view class="case-cont">
					<view class="box" v-for="(item,id) in arrcase" :key="id">
						<image :src="item.litpic"></image>
						<text>{{item.title}}</text>
					</view>
				</view>
			</view>


			<view class="member">
				<image :src="imgurl+'hyzk.png'"></image>
			</view>

			<view class="box">
				<view class="box-left">
					<swiper>
						<swiper-item v-for="(item,index) in banner_image" :key="index">
							<image :src="item.litpic" @click="tobuy"></image>
						</swiper-item>
					</swiper>

				</view>
				<view class="box-right">
					<view class="handpick">
						<view class="handpick-top">
							<text>闪电精选</text>
						</view>
						<view class="handpick-cont">
							<view class="image" v-for="(item,index) in 2" :key="index">
								<image :src="imgurl+'18.png'"></image>
							</view>
						</view>
					</view>

					<view class="handpick">
						<view class="handpick-top">
							<text>入夏优惠</text>
						</view>
						<view class="handpick-cont">
							<view class="image" v-for="(item,index) in 2" :key="index">
								<image :src="imgurl+'18.png'"></image>
							</view>
						</view>
					</view>

				</view>
			</view>

			<!-- banner图 -->
			<!-- <view class="bannner">
				<swiper>
					<swiper-item v-for="(item,index) in banner_image" :key="index"> 
						<image :src="item.litpic"></image>
					</swiper-item>
				</swiper>
				
			</view> -->


			<!-- 闪电精选 -->
			<!-- <view class="sift">
				<view class="sift-top">
					<text>闪电精选</text>
				</view>
				<view class="sift-cont">
					<view class="image" v-for="(item,index) in arrsift" :key="index">
						<image :src="item.image"></image>
					</view>
				</view>
			</view> -->



			<!-- <scroll-view scroll-x class="nav" scroll-with-animation :scroll-left="scrollLeft">
				<view class="cu-item" :class="index==TabCur?'text-green cur':''" v-for="(item,index) in arrlist" :key="index" @tap="tabSelect" :data-id="index">
					<view class="top">
						<image :src="item.image"></image>
						<text>{{item.title}}</text>
					</view>
					<view class="bottom">
						<text>{{item.text}}</text>
					</view>
				</view>
			</scroll-view> -->
		</view>

		<view class="nav-cont" v-if="TabCur==0">
			<view class="rec">
				<view class="rec-top">
					<image src="../../static/image/rec.png"></image>
				</view>
				<view class="mend" v-for="(item,index) in arrNavCont" :key="index" @click="detil(item.id)">
					<view class="image">
						<image :src="item.image"></image>
					</view>
					<view class="title">
						<text class="name">{{item.store_name}}</text>
						<view class="price">
							<text>￥</text>
							<text>{{item.price}}</text>
						</view>
					</view>
				</view>
			</view>
		</view>




		<!-- 优惠券-->
		<view class="coupons" v-if="showCoupon" @click="closeCoupon">
			<view class="cou" @click.stop="stop">
				<image class="bg" :src="imgurl+'1.png'"></image>
				<scroll-view scroll-y="true">
					<view class="coupon" v-for="(item,index) in arrcoupon" :key="index">
						<view class="coupon-top">
							<text>¥</text>
							<text>{{item.info.coupon_price}}</text>
							<view class="name">
								{{item.info.title}}
							</view>
						</view>
						<view class="time">
							<text>有效期：{{item.end_time}}</text>
						</view>
						
					</view>
				</scroll-view>
				<view class="use" @click="draw">立即领取</view>
			</view>
		</view>


		<!-- 底部填充 -->
		<view class="kong"></view>

		<!-- 底部tabbar -->
		<view class="cu-bar tabbar bg-white">
			<navigator class="action text-orange">
				<image src="../../static/icon/shouye2.png"></image>
				<text>首页</text>
			</navigator>
			<navigator url="../classify/classify" class="action text-black">
				<image class="cu_img" src="../../static/icon/fenlei1.png"></image>
				<text>分类</text>
			</navigator>
			<navigator url="../shanyue/shanyue" class="action text-black add-action">
				<image class="cu_mid" src="../../static/icon/shanyue.png"></image>
				<text>闪约</text>
			</navigator>
			<navigator url="../indent/indent" class="action text-black">
				<image class="cu_img" src="../../static/icon/dingdan1.png"></image>
				<text>订单</text>
			</navigator>
			<navigator url="../user/user" class="action text-black">
				<image class="bag" src="../../static/icon/wode1.png"></image>
				<text>我的</text>
			</navigator>
		</view>
	</view>
</template>

<script>
	import {
		getIndex,
		getIndexSift,
		getCoupon,
		postCoupon
	} from '../../api/api.js';
	export default {
		data() {
			return {
				imgurl:getApp().globalData.imgUrl,
				TabCur: 0,
				scrollLeft: 0,
				city: '济南',
				swiper: [],
				nav: [],
				arrcase: [],
				// 闪电精选
				arrsift: [],
				arrlist: [{
					id: 1,
					image: "../../static/index/20.png",
					title: "精选",
					text: "为您推荐"
				}, ],
				banner_image: [],
				arrNavCont: [

				],
				page: 1, //首页下方服务
				showCoupon: true,
				arrcoupon: [{
					id: 1,
					price: 1980,
					name: "下单帝康指纹锁直接抵扣",
					time: "2021-07-01"
				}, {
					id: 2,
					price: 98,
					name: "下单指定商品赠送年会员",
					time: "2021-07-01"
				}, {
					id: 3,
					price: 20,
					name: "下单指定服务直接抵扣20元",
					time: "2021-07-01"
				}, {
					id: 3,
					price: 10,
					name: "下单指定服务直接抵扣20元",
					time: "2021-07-01"
				}]
			}
		},
		onLoad(option) {
			uni.setStorage({
				key: "scene",
				data: option.scene
			})
		},
		onShow() {
			this.getindex();
			this.getIndexsift();
			this.getCou()
		},
		onReachBottom() {
			this.page += 1;
			this.getIndexsift();
		},
		methods: {
			tabSelect(e) {
				console.log(e)
				this.TabCur = e.currentTarget.dataset.id;
				this.scrollLeft = (e.currentTarget.dataset.id - 1) * 60
			},
			// 获取首页内容
			getindex() {
				let _this = this
				getIndex({

				}).then(res => {
					console.log(res)
					_this.swiper = res.data.data.banner
					_this.nav = res.data.data.menus
					_this.arrcase = res.data.data.shandianda
					_this.arrsift = res.data.data.jingxuan
					_this.banner_image = res.data.data.zhineng_banner

				})
			},
			// 获取首页下方服务
			getIndexsift() {
				getIndexSift({
					page: this.page
				}).then(res => {
					// console.log(res)
					this.arrNavCont = this.arrNavCont.concat(res.data.data)
				})
			},

			// 获取优惠券列表
			getCou() {
				getCoupon({}).then(res => {
					console.log(res)
					this.arrcoupon = res.data.data
				})
			},
			closeCoupon() {
				this.showCoupon = false
			},
			stop() {},
			
			
			draw(){
				console.log(this.arrcoupon)
				var id='';
				for(var i=0;i<this.arrcoupon.length;i++){
					id=id+this.arrcoupon[i].id+','
				}
				console.log(id)
				postCoupon({
					couponId: id
				}).then(res => {
					console.log(res)
					uni.showToast({
						title: res.data.msg,
						duration: 1500,
						icon: "none"
					})
					this.showCoupon = false
				})
			},
			// 选择nav
			choose(index) {
				console.log(index)
				uni.navigateTo({
					url: "../classify/classify?type=" + index
				})
			},
			
			
			// 搜索
			tosearch(){
				uni.navigateTo({
					url:"../../other/pages/search/search"
				})
			},
			
			// 商品详情
			detil(id) {
				uni.navigateTo({
					url: "../spxq/spxq?id=" + id
				})
			},
			// 买锁
			tobuy() {
				uni.navigateTo({
					url: "../buy_lock/buy_lock"
				})
			}
		}
	}
</script>

<style scoped>
	@import './index.css';
</style>
