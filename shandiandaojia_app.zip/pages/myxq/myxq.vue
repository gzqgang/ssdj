<template>
	<view>
		<view class="end-title">
		　　<view @tap="change(0)" :class="{btna:btnnum == 0}">
				<text>全部</text>
			</view>
		  　<view @tap="change(1)" :class="{btna:btnnum == 1}">
			 	<text>发布中</text>
			</view>
		　　<view @tap="change(2)" :class="{btna:btnnum == 2}">
				<text>已取消</text>
			</view>
			<view @tap="change(3)" :class="{btna:btnnum == 3}">
				<text>已完成</text>
			</view>

		</view>
		<view class="end-cont" :class="{dis:btnnum == 0}">
			<!-- 如果为空 -->
			<view class="empty">
				<text>暂无任何需求</text>
			</view>
			
			
			
			
			
			<!--  -->
		</view>
		<view class="end-cont" :class="{dis:btnnum == 1}">
		 　　
		</view>
		<view class="end-cont" :class="{dis:btnnum == 2}">
		  　
		</view>
		
		<view class="issue">
			<image src="../../static/icon/shanyue.png"></image>
			<text>免费发布需求，让技工主动来约</text>
		</view>
		
		
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				btnnum: 0,
				arrIndent:[],
			}
		},
		onLoad() {
			
		},
		methods: {
			change(e) {
			      this.btnnum = e
			  }
		}
	}
</script>

<style scoped>
@import './myxq.css'
</style>
