
<template>
	<!-- 支付结果 -->
	<view>
		<view class="imgs">
			<image src="../../static/image/pjcg.png"></image>
		</view>
		<view class="title">
			<text v-if="result==0">支付成功</text>
			<text v-if="result==1">支付失败</text>
			<text>感谢您的惠顾</text>
			<text>我们将继续提供更好的商品~</text>
		</view>
		
		<view class="submit" @click="toindex">返回首页</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				result:'',
			}
		},
		onLoad(option) {
			console.log(option)
			this.result=JSON.parse(option.res)
			console.log(this.result)
		},
		methods: {
			toindex(){
				uni.redirectTo({
					url:"../index/index"
				})
			}
		}
	}
</script>

<style scoped>
@import './zfjg.css';
</style>



