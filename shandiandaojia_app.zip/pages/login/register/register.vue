<template>
	<view>
		<view class="bg-img">
			<text>闪电到家</text>
			<text>服务万家</text>
			
		</view>
		<form @submit="formSubmit">
		<view class="form">
			<text class="reg">注册</text>
			<view class="inputs">
				<input type="text" name="phone" placeholder="请输入手机号"/>
			</view>
			<view class="inputs">
				<input type="text"  name="captcha"  placeholder="请输入验证码" />
				<button @click="getCode">
					{{!codeTime?'获取验证码':codeTime+'s'}}
					</button>
			</view>
			<view class="inputs">
				<input  :type="seen? type_text : type_password" name="password" class="input" placeholder="请设置密码" />
				 <view class="see" v-show='seen' @click="changeSeen">
				             <image src="../../../static/icon/zhengyan.png"></image>
				     </view>
				   <view class="see" v-show='!seen' @click="changeSeen">
				        <image src="../../../static/icon/biyan.png"></image>
				 </view>
			</view>
			
		</view>
		
		
		<button class="submit" form-type="submit">注册</button>
		</form>
		<view class="text">登录注册表示同意《用户协议》与《隐私条款》</view>
		
	</view>
</template>

<script>
	import {postRegister} from '../../../api/api.js';
	export default {
		data() {
			return {
				seen: false,
				type_text: "text",
				type_password: "password",
				codeTime:0,
				form:{
					phone:'',
					password:'',
					captcha:''
				},
				spread:'',
			}
		},
		onLoad(option) {
			var _this = this
			   uni.getStorage({
			    key:"scene",
			    success:function(res){
			     console.log(res,'===========')
			     _this.spread=res.data
			     console.log(_this.spread)
			    }
			   })
		},
		methods: {
			// 查看密码
			changeSeen(){
			     this.seen = !this.seen;
			 },
			tologin(){
				uni.navigateBack({
					delta:1
				})
			},
			
			getCode() {
			      if(this.codeTime>0){
			      					uni.showToast({
			      						title: '不能重复获取',
			      						icon:"none"
			      					});
			      				    return;
			      				}else{
			      					this.codeTime = 60
			      					let timer = setInterval(()=>{
			      						this.codeTime--;
			      						if(this.codeTime<1){
			      							clearInterval(timer);
			      							this.codeTime = 0
			      						}
			      					},1000)
							}
			},
			formSubmit(e){
				uni.showLoading({
				    mask: true,
				})
				
				// console.log('form发生了submit事件，携带数据为：',e.detail.value)
				let self = this;
				let val = e.detail.value
				postRegister({
					phone:val.phone,
					password:val.password,
					captcha:val.captcha,
					spread:self.spread
				}).then(res=>{
					console.log(res)
					uni.hideLoading()
					uni.showToast({
						title:res.data.msg,
						duration:1500,
						icon:"none"
					})
					setTimeout(function() {
						if(res.data.code==1){
							uni.navigateTo({
								url:"../login"
							})
						}
					}, 1500);
				})
			},
			// 注册
			submit(){
				
			}
			
		}
	}
</script>

<style scoped>
@import './register.css';
</style>
