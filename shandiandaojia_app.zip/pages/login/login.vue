<template>
	<view>
		<view class="bg-img">
			<text>闪电到家</text>
			<text>服务万家</text>
		</view>
		<view class="box">
			<text>账号</text>
			<input type="text" v-model="phone" placeholder="请输入你的账号" placeholder-style="color:#8b8b8b"/>
		</view>
		
		<view class="box">
			<text>密码</text>
			<input type="password" v-model="password" placeholder="请输入密码" placeholder-style="color:#8b8b8b"/>
		</view>
		
		<view class="title">
			<text @click="toregister">注册</text>
			<text>忘记密码?</text>
		</view>
		
		<view class="submit" @click="submit">登录</view>
		
		<view class="image">
			<image src="../../static/icon/phoneLogin.png"></image>
			<image src="../../static/icon/wxLogin.png" @click="wxLogun"></image>
		</view>
	</view>
</template>

<script>
	import {postLogin,wxLogin} from '../../api/api.js';
	export default {
		data() {
			return {
				phone:'',
				password:'',
				code:'',
				iv:'',
				encrytip:'',
				spread:'',
			}
		},
		onLoad(option) {
			var _this = this
			   uni.getStorage({
			    key:"scene",
			    success:function(res){
			     console.log(res,'===========')
			     _this.spread=res.data
			     console.log(_this.spread)
			    }
			   })
		},
		methods: {
			toregister(){
				uni.navigateTo({
					url:"register/register"
				})
			},
			submit(){
				postLogin({
					phone:this.phone,
					password:this.password
				}).then(res=>{
					console.log(res)
					uni.showToast({
						title:res.data.msg,
						duration:1500,
						icon:"none"
					})
					if(res.data.code==1){
						uni.setStorage({
							key:"token",
							data:res.data.data.token
						})
						setTimeout(function() {
							uni.navigateTo({
								url:"../index/index"
							})
						}, 1500);
					}
				})
			},
			wxLogun(){
				let self=this
				uni.login({
					success(res) {
						console.log(res)
						self.code=res.code
					}
				})
				uni.getUserProfile({
					desc:"获取头像名字",
					success:(res)=>{
						console.log(res,"1212")
						wxLogin({
							code:self.code,
							iv:res.iv,
							encryptedData:res.encryptedData,
							spread:self.spread
						}).then(re=>{
							console.log(re,"855")
							uni.setStorage({
								key:"token",
								data:re.data.data.token
							})
							setTimeout(function() {
								uni.navigateTo({
									url:"../index/index"
								})
							}, 1500);
						})
					}
				})
			}
		}
	}
</script>

<style scoped>
@import './login.css';
</style>
