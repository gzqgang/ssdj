<template>
	<!-- 订单详情 -->
	<view>
		<view class="xq2" v-if="arrIndent.status==0">
			<view class="pay">
				<text>待支付</text>
				<text>交易将在30分钟内关闭，请及时付款！</text>
				<view></view>
			</view>
			<view class="content">
				<view class="good">
					<view class="image">
						<image :src="arrIndent.cartInfo[0].productInfo.image"></image>
					</view>
					<view class="title">
						<view class="site">服务地址：{{arrIndent.user_address}}</view>
						<view class="time">上门时间：{{arrIndent.fuwu_time_y}}</view>
					</view>
				</view>
				<view class="prices">
					<view class="case">
						<text>服务金额</text>
						<text>{{arrIndent.cartInfo[0].productInfo.price}}元</text>
					</view>
					<view class="case">
						<text>夜间交通费</text>
						<text>{{arrIndent.jiaotong_money}}元</text>
					</view>
					<view class="case">
						<text>优惠金额</text>
						<text>0元</text>
					</view>
				</view>
				
				<view class="boxx">
					<view class="total">
						<text>实付金额</text>
						<text>{{arrIndent.pay_price}}元</text>
					</view>
					<view class="text">订单信息</view>
					<view class="time">
						<text>订单编号：{{arrIndent.order_id}}</text>
						<text>创建时间：{{arrIndent.add_time_y}}</text>
						<!-- <text>付款时间：{{arrIndent.pay_time}}</text> -->
					</view>
				</view>
			</view>
		<view class="payment" @click="topay">立即支付</view>
		
		</view>
		<view class="xq1" v-if="arrIndent.status!=0">
		<view class="box">
			<view class="goods">
				<view class="image">
					<image :src="arrIndent.cartInfo[0].productInfo.image"></image>
				</view>
				<view class="title">
					<view class="name">
					
					</view>
					<view class="site">服务地址：{{arrIndent.user_address}}</view>
					<view class="time">上门时间：{{arrIndent.fuwu_time_y}}</view>
					<!-- <view class="number">服务人员：{{arrIndent._pay_time}}</view> -->
				</view>
				<view class="bottom">
					<view class="btn">
						<view class="box1" v-if="arrIndent.status==1" @click="openCancel">取消订单</view>
						<!-- <view class="box1" v-if="arrIndent.status==2 || arrIndent.status==3" @click="tofanx">申请售后</view> -->
						<view class="box2" v-if="arrIndent.status==1">等待接待...</view>
						<view class="box3" v-if="arrIndent.status==2">确认完成</view>
						<view class="box3" v-if="arrIndent.status==3">晒评价</view>
						
					</view>
				</view>
			</view>
			<view class="price">
				<view class="case">
					<text>服务金额</text>
					<text>{{arrIndent.cartInfo[0].productInfo.price}}元</text>
				</view>
				<view class="case">
					<text>夜间交通费</text>
					<text>{{arrIndent.jiaotong_money}}元</text>
				</view>
				<view class="case">
					<text>优惠金额</text>
					<text>0元</text>
				</view>
			</view>
			
			<view class="boxs">
				<view class="total">
					<text>实付金额</text>
					<text>{{arrIndent.pay_price}}元</text>
				</view>
				<view class="text">订单信息</view>
				<view class="time">
					<text>订单编号：{{arrIndent.order_id}}</text>
					<text>创建时间：{{arrIndent.add_time_y}}</text>
					<text>付款时间：{{arrIndent.pay_time_y}}</text>
				</view>
			</view>
			
		</view>
		
		
	</view>
		
		
		
		
		
		<!-- 取消订单 -->
		<view class="cancel" v-if="showCancel" @click="closeCancel">
			<view class="can" @click.stop="stop">
				<view class="can-top">取消订单</view>
				<view class="can-middle">
					<radio-group>
					<view class="box1" v-for="(item,index) in cancles" :key="index">
						<radio></radio>
						<text>{{item}}</text>
					</view>
					</radio-group>
				</view>
				<view class="submit">提交</view>
			</view>
			
		</view>
		
		
	</view>
</template>

<script>
	import {getOrderDetail,getFuwuDetail} from '../../api/api.js';
	export default {
		data() {
			return {
				showCancel:false,
				orderId:'',
				total:100,
				arrIndent:{
					
				},
				cancles:[
					"地址填写有误",
					"忘记使用优惠券",
					"需要更改预约时间",
					"重复下单/误下单",
					"支付方式有误/无法支付",
					"长时间未接单",
					"不需要了",
					"其他原因"
				],
				ctype:''
			}
		},
		onLoad(options) {
			console.log(options)
			this.orderId=options.orderId
			this.ctype=options.ctype
			console.log(this.orderId)
		},
		onShow() {
			this.getDetail();
		},
		methods: {
			closeCancel(){
				this.showCancel=false
			},
			openCancel(){
				this.showCancel=true
			},
			stop(){},
			// 跳转申请售后
			tofanx(){
				uni.navigateTo({
					url:"../../other/pages/fanx/fanx"
				})
			},
			// 获取订单详情
			getDetail(){
				if(this.ctype=='fuwu'){
					getFuwuDetail({
						order_id:this.orderId
					}).then(res=>{
						console.log(res)
						this.arrIndent=res.data.data
					})
				}else{
					getOrderDetail({
						order_id:this.orderId
					}).then(res=>{
						console.log(res)
						this.arrIndent=res.data.data
					})
				}
				
				
			},
			// 立即支付
			topay(){
				var orderId=this.arrIndent.order_id;
				uni.navigateTo({
					url:"../zffs/zffs?orderId="+orderId
				})
			},
		}
	}
</script>

<style scoped>
@import './ddxq.css';
</style>
