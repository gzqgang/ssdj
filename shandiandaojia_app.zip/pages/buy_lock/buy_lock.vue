<template>
	<view>
		<image class="zuo" src="../../static/icon/zuo-fff.png" @click="pageUp"></image>
		<view class="suo" v-for="(item,id) in arrSuo" :key="id" @click="toqrdd(item.id)">
			<image :src="item.image"></image>
		</view>
		
	</view>
</template>

<script>
	import {getSuo} from '../../api/api.js';
	export default {
		data() {
			return {
				arrSuo:[],
			}
		},
		onShow() {
			this.getsuo();
		},
		methods: {
			getsuo(){
				getSuo({
					
				}).then(res=>{
					console.log(res)
					this.arrSuo=res.data.data
				})
			},
			
			// 跳转
			toqrdd(id){
				uni.navigateTo({
					url:"../qrdd2/qrdd2?id="+id
				})
			},
			// 上一页
			pageUp(){
				uni.navigateBack({
					delta:1
				})
			},
		}
	}
</script>

<style scoped>
@import './buy_lock.css';
</style>
