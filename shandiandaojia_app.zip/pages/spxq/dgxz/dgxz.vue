<template>
	<!-- 订购须知 -->
	<view>
		<view class="banner">
			<image :src="imgurl+'dgxz.png'"></image>
		</view>
		
		<view class="content">
			<view class="left">
				<view class="box">
					<view class="boxs">01</view>
				</view>
			</view>
			<view class="right">
				<view class="title">商家接单</view>
				<view class="text">用户付款下单后，商家需在30分钟内确认是否接单。如果下单时间不在营业时间,商家需在次日上班后60分钟内确认是否接单。</view>
			</view>
		</view>
		<view class="content">
			<view class="left">
				<view class="box">
					<view class="boxs">02</view>
				</view>
			</view>
			<view class="right">
				<view class="title">正常退款</view>
				<view class="text">商家已确认接单后,在商家营业时间内、离约定时间2小时之前，用户申请退款的,商家应予以100%退款。</view>
			</view>
		</view>
		<view class="content">
			<view class="left">
				<view class="box">
					<view class="boxs">03</view>
				</view>
			</view>
			<view class="right">
				<view class="title">商家爽约</view>
				<view class="text">商家已确认接单后，商家单方面再取消订单或在未事先取得用户同意的情况下超过约定时间2小时仍未上门的，均视为商家爽约。用户申请退款时，若尚未开始服务商家须将已付款项予以100%退款，并通过到位平台向用户另行赔付30元爽约金。</view>
			</view>
		</view>
		<view class="content">
			<view class="left">
				<view class="box">
					<view class="boxs">04</view>
				</view>
			</view>
			<view class="right">
				<view class="title">用户爽约</view>
				<view class="text">商家已确认接单后。用户单方面在离约定时间2小时内申请退款、商家按时上门后用户拒绝接受服务、商家按时上门后无法联系到用户导致未能捉供服务，均视为用户爽约。商家可按已安排的服务人员数扣取30元/人的爽约金(空单费)。如商家巳安排服务车辆上门的,可另行扣取最高不超过100元/辆的空驶费，其余部分应予以退款。</view>
			</view>
		</view>
		
		<view class="content">
			<view class="left">
				<view class="box">
					<view class="boxs">05</view>
				</view>
			</view>
			<view class="right">
				<view class="title">协商退款</view>
				<view class="text">在商家开始服务后,如果用户对商家提供的服务不满意用户可向商家申请部分退款，具体退金额需和商家协商。协商不成的将由到位平台客服进行仲裁,以保障用户和商家双方的合理权益。</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				imgurl:getApp().globalData.imgUrl
			}
		},
		methods: {
			
		}
	}
</script>

<style scoped>
@import './dgxz.css'
</style>
