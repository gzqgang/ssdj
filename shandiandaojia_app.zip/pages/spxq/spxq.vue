<template>
	<!-- 商品详情 -->
	<view>
		<!-- 消息 -->
		<view class="xiaoxi">
			<image :src="imgurl+'xiaoxi.png'"></image>
		</view>
		<view class="swiper"> 
			<swiper autoplay="true" indicator-dots="true" indicator-active-color="#FF9017">
				<swiper-item v-for="(item,id) in storeInfo.slider_image" :key="id">
					<image :src="item"></image>
				</swiper-item>
			</swiper>
		</view>
		<!-- 详情 -->
		<view class="detail">
			<!-- 分享 收藏 -->
			<view class="fun">
				<view class="headLine">
					{{headLine}}
				</view>
				<view class="funs">
					<image src="../../static/img/fenxiang.png"></image>
					<image src="../../static/img/shoucang.png"></image>
				</view>
			</view>
			<!-- 商品选择 -->
			<view class="shop">
				<!-- <scroll-view  class="scroll-x" scroll-x> -->
					<!-- <view :class="item.id==shopid? 'boxs':'box'" v-for="(item,index) in arrshop" :key="index" @click="chose(item)"> -->
						<view class="name">
							{{storeInfo.store_name}}
						</view>
						<view class="price">
							<text>{{storeInfo.price}}</text>
							<text>元/{{storeInfo.unit_name}}</text>
						</view>
					<!-- </view> -->
				<!-- </scroll-view> -->
			</view>
			<!-- 优惠券 -->
			<view class="coupon">
				<image :src="imgurl+'coup.png'"></image>
				<text>券后预计289/小时</text>
			</view>
			<!-- 活动 -->
			<view class="act">
				<text>活动</text>
			</view>
			<view class="act">
				<text>保障</text>
				<view class="safe">
					<view class="box">
						<image src="../../static/img/bao.png"></image>
						<text>未服务全额退</text>
					</view>
					<view class="box">
						<image src="../../static/img/bao.png"></image>
						<text>爽约包赔</text>
					</view>
					<view class="box">
						<image src="../../static/img/bao.png"></image>
						<text>不满意重服务</text>
					</view>
				</view>
			</view>
		</view>
		<!-- 选择 -->
		<view class="choose">
			<view class="left">选择</view>
			<view class="right" @click="openShop">
				<text>{{shopname==''? '选择项目':shopname}}</text>
				<image src="../../static/image/you.png"></image>
			</view>
		</view>
		
		<!--服务时间-->
		<!-- <view class="choose">
			<view class="left">服务时间</view>
			<view class="right">
				<text>{{datatime}}</text>
				<image src="../../static/image/you.png"></image>
			</view>
		</view> -->
		
		<!-- 简介 -->
		<view class="intro">
			<text>简介</text>
		</view>
		
		<!-- 订购须知 -->
		<view class="notice">
			<view class="notice-top" @click="todgxz">
				<text>订购须知</text>
				<text>取消、退款、赔付规则 ></text>
			</view>
			<view class="notice-bottom">
				<ol>
					<li>该项目由闪电到家就近接单、规范服务;</li>
					<li>如下单30分钟无商家接单，建议取消再重新下单;</li>
					<li>商家接单后，修改订单或退款需提前2小时通知;</li>
					<li>预约时间前2小时内退单将按30元/人扣取空单费;</li>
					<li>如商家接单后爽约将全额退款并向您额外赔付30元;</li>
				</ol>
			</view>
		</view>
		
		<!-- 图文详情 -->
		<view class="imgDetil">
			<text>图文详情</text>
		</view>
		<view class="det-img">
			<rich-text style="width: 100%;" :nodes="storeInfo.description"></rich-text>
		</view>
		
		
		<!-- 商品评价 -->
		<view class="imgDetil">
			<text>商品评价</text>
		</view>
		<view class="eva">
			<view class="eva-top">
				<view>
					<checkbox></checkbox>
					<text>只看当前服务</text>
				</view>
					<text>好评率96%</text>
			</view>
			<view class="eva-choose">
				<li>
					<text>100</text>
					<text>全部</text>
				</li>
				<li>
					<text>100</text>
					<text>好评</text>
				</li>
				<li>
					<text>100</text>
					<text>中评</text>
				</li>
				<li>
					<text>100</text>
					<text>差评</text>
				</li>
				<li>
					<text>100</text>
					<text>有图</text>
				</li>
			</view>
			<view class="luate" v-for="(item,index) in arrEva" :key="index">
				<view class="luate-top">
					<image :src="item.image"></image>
					<view class="title">
						<view class="name">{{item.name}}</view>
						<view class="times">
							<image src="../../static/img/xing.png"></image>
							<image src="../../static/img/xing.png"></image>
							<image src="../../static/img/xing.png"></image>
							<image src="../../static/img/xing.png"></image>
							<image src="../../static/img/xing.png"></image>
							<text>{{item.time}}</text>		
						</view>
					</view>
					
				</view>
				<view class="luates">
					<view class="luates-top">
						<view class="box" v-for="(itme,id) in item.list" :key="id">
							{{itme}}
						</view>
					</view>
					<view class="luates-middle">
						{{item.content}}
					</view>
					<view class="luates-bottom">
						<text>{{item.artisan.site}}</text>
						<text>{{item.artisan.text}}</text>
						<text>{{item.artisan.name}}</text>
					</view>
				</view>
				
			</view>
			
			
		</view>
		
		
		
		
		<!-- 选择弹框 -->
		
		<view class="popup" @click="closeShop" v-if="showShop">
			
			<view class="pop" @click.stop="stop">
				<view class="pop-top">
					<view class="pop-image">
						<image :src="product_text.image"></image>
					</view>
					<view class="pop-title">
						<text>{{storeInfo.store_name}}</text>
						<text>已选：{{product_text.suk}}</text>
						<text>{{product_text.price}}元/{{storeInfo.unit_name}}</text>
					</view>
				</view>
				<view class="project" v-for="(item,id) in arrproductAttr" :key="id">
					<view class="pro-title">服务项目</view>
					<view class="pro-cont" >
						<view class="pro-chose" :class="{optfor:chPro==itme.check}" v-for="(itme,index) in item.attr_value" :key="index" @click="choosePro(id,itme)">
							{{itme.attr}}
						</view>
					</view>
				</view>
				
				<!-- <view class="size">
					<view class="pro-title">服务规格</view>
					<view class="size-cont" >
						<view class="size-chose" :class="{optfor:chSize==item.id}" v-for="(item,index) in arrSize" :key="index" @click="chooseSize(item)">
							{{item.text}}
						</view>
					</view>
				</view> -->
				<!-- 购买数量 -->
				<view class="nums">
					<view class="pro-title">购买数量</view>
					<view class="num">
						<view class="box" @click="reduceNum">-</view>
							<input style="width: 50rpx;" type="text" v-model="number" />
						<view class="box" @click="addNum">+</view>
					</view>
				</view>
				
				<view class="affirm" @click="affirm">确认选择</view>
				
				
				
			</view>
		</view>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<!-- 底部 -->
		<view class="bottom">
			<view class="service">
				<image src="../../static/shop/kefu.png"></image>
				<text>客服</text>
			</view>
			<view class="submit" @click="openShop">立即购买</view>
		</view>
		
		
		
	</view>
</template>

<script>
	import {getShopDetail} from '../../api/api.js';
	export default {
		data() {
			return {
					imgurl:getApp().globalData.imgUrl,
					number:1,
					showShop:false,
					storeInfo:{},
					shopImg:["../../static/shop/shopimg.png","../../static/shop/shopimg.png"],
					headLine:"深度清理",
					shopid:1,
					shopname:"全屋深度保洁套餐",
					datatime:"2021/05/25 16:30",
					arrproductAttr:[],
					arrshop:[
					
					],
					chPro:true,//选择商品
				
					chSize:'',
					coupon:{text:"券后预计289/小时"},
					
					attr_text:'',
					productValue:[],
					product_text:'',
					unique:'',
					arrEva:[
							{
								id:1,
								name:"张三",
								image:getApp().globalData.imgUrl+'header.jpg',
								time:"2025-05-25",
								content:"非常满意",
								list:["打扫精致","干活麻利","工具齐全"],
								artisan:{
									name:"朱永亮",
									text:"全屋深度保洁套餐",
									site:"北京 朝阳区",
								},
							}
					],
					
					id:'',
			}
		},
		onLoad(option) {
			this.id=option.id
		},
		onShow() {
			this.getShop();
		},
		methods: {
			// 商品详情
			getShop(){
				getShopDetail({
					id:this.id
				}).then(res=>{
					console.log(res)
					this.storeInfo=res.data.data.storeInfo
					this.product_text=res.data.data.storeInfo
					this.arrproductAttr=res.data.data.productAttr
					this.productValue=res.data.data.productValue
				})
				
				
			},
			
			// 订购须知
			todgxz(){
				uni.navigateTo({
					url:"dgxz/dgxz"
				})
			},
			
			// 弹框
			closeShop(){
				this.showShop=false
			},
			openShop(){
				this.showShop=true
			},
			stop(){},
			// 选择商品
			chose(item){
				console.log(item)
			},
			// 选择服务
			choosePro(id,itme){
				// console.log(id)
				// console.log(itme)
				for(var i = 0;i<this.arrproductAttr.length;i++){
					if(id==i){
						for(var j=0;j<this.arrproductAttr[i].attr_value.length;j++){
							
							if(itme.attr==this.arrproductAttr[i].attr_value[j].attr){
								this.arrproductAttr[i].attr_value[j].check=!this.arrproductAttr[i].attr_value[j].check
							}else{
								this.arrproductAttr[i].attr_value[j].check=false
							}
							
						}
					}
					
				}
				this.affirmService()
			},
			chooseSize(item){
				this.chSize=item.id
			},
			
			// 加减
			addNum(){
				let self = this;
				self.number = self.number +1;
				// if(self.num >= self.productSelect.stock){
				// 	console.log('不加')
				// }else{
				// 	console.log('加')
					
				// }
			},
			reduceNum(){
				let self = this;
				if(self.number == 1){
					uni.showToast({
						title:"不能再减了",
						duration:1500,
						icon:"none"
					})
				}else{
					self.number = self.number -1;
				}
			},
			// 确认选择
			affirmService(){
				let text = ''
				for(var i=0;i<this.arrproductAttr.length;i++){
						for(var j=0;j<this.arrproductAttr[i].attr_value.length;j++){
							  if(this.arrproductAttr[i].attr_value[j].check==true){
								  
								  if(text==''){
									  text=this.arrproductAttr[i].attr_value[j].attr
								  }else{
									  text=text+','+this.arrproductAttr[i].attr_value[j].attr
								  }
							  }
							}
						}
				
				this.attr_text=text
				console.log(this.productValue[text])
				if(this.productValue[text]==undefined){
					if(this.product_text==''){
						this.product_text=this.storeInfo
					}
				}else{
					this.product_text=this.productValue[text]
					this.unique=this.productValue[text].unique
				}
			},
			affirm(){
				let self = this
				if(this.unique==''){
					uni.showToast({
						title:"请选择服务或商品",
						duration:2000,
						icon:"none"
					})
				}else{
					uni.navigateTo({
						url:"../qrdd/qrdd?unique="+self.unique+"&num="+self.number+"&id="+this.storeInfo.id
					})
				}
				
			}
		
		}
	}
</script>

<style scoped>
@import './spxq.css';
</style>
