<template>
	<!-- 买锁确认订单 -->
	<view>
		<!-- 地址 -->
		<view class="site">
			<view class="box" @click="openSite">
				<view class="img">
					<image src="../../static/img/jiudian.png"></image>
				</view>
				<view class="title">
					<view class="address">
						<text>服务地址</text>
						<text>{{address.province}}{{address.city}}{{address.district}}</text>
					</view>
					<image src="../../static/image/you.png" mode=""></image>
				</view>
			</view>
			<view class="box">

				<view class="img">
					<image src="../../static/img/shengshiqu.png"></image>
				</view>
				<view class="title">
					{{address.detail}}
				</view>

			</view>
			<view class="box">

				<view class="img">
					<image src="../../static/img/name.png"></image>
				</view>
				<view class="title">
					{{address.real_name}}
				</view>

			</view>
			<view class="box">

				<view class="img">
					<image src="../../static/img/phone.png"></image>
				</view>
				<view class="title">
					<view class="address">
						<text>联系电话</text>
						<text>{{address.phone}}</text>
					</view>

				</view>
			</view>
		</view>

		<!-- 服务时间 -->
		<view class="time">
			<view class="img">
				<image src="../../static/img/Clock2.png"></image>
			</view>
			<view class="title">
				<text>服务时间</text>
				<text @click="showMask">{{time==''? '请选择预约时间': time}}</text>
				<hTimeAlert title="预约时间" subhead="我是副标题" rangeStartTime="00:00:00" rangeEndTime="24:00:00" defaultTime="2020/3/29 18:00:00"
				 intervalTime="30" dayStartIntTime="0" rangeDay="5" :isShow="isShow" :maskHide="maskHide" :rangeType="rangeType"
				 :closeBtn="closeBtn" @closeAlert="handelClose"></hTimeAlert>
			</view>
		</view>

		<view class="suo">
			<view class="suo-top">
				<text>拍照上传现用门锁照片</text>
				<text>点击查看示例</text>
			</view>
			<view class="suo-cont">
				<view class="suo-img">
					<view class="imgs">
						<view class="picture" v-for="(item,index) in imgWc" :key="index" :data-url="imgWc[index]">
							<image :src="imgWc[index]" mode="aspectFill"></image>
							<view class="del bg-red" @tap.stop="DelZgzImg" :data-index="index">
								<text class='cuIcon-close'></text>
							</view>
						</view>
						<view class="solid" @tap="ChooseZgzImage" v-if="imgWc.length<1">
							<text class='cuIcon-cameraadd'></text>
						</view>
					</view>
					<text class="suo-text">外侧门锁正面照</text>
				</view>
				<view class="suo-img">
					<view class="imgs">
						<view class="picture" v-for="(item,index) in imgNc" :key="index" :data-url="imgNc[index]">
							<image :src="imgNc[index]" mode="aspectFill"></image>
							<view class="del bg-red" @tap.stop="DelNcImg" :data-index="index">
								<text class='cuIcon-close'></text>
							</view>
						</view>
						<view class="solid" @tap="ChooseNcImage" v-if="imgNc.length<1">
							<text class='cuIcon-cameraadd'></text>
						</view>
					</view>
					<text class="suo-text">内侧门锁正面照</text>
				</view>
				<view class="suo-img">
					<view class="imgs">
						<view class="picture" v-for="(item,index) in imgCm" :key="index" :data-url="imgCm[index]">
							<image :src="imgCm[index]" mode="aspectFill"></image>
							<view class="del bg-red" @tap.stop="DelCmImg" :data-index="index">
								<text class='cuIcon-close'></text>
							</view>
						</view>
						<view class="solid" @tap="ChooseCmImage" v-if="imgCm.length<1">
							<text class='cuIcon-cameraadd'></text>
						</view>
					</view>
					<text class="suo-text">侧面锁体照</text>
				</view>
			</view>
		</view>


		<!-- 商品 -->
		<view class="shop">
			<view class="store" v-for="(item,index) in arrstore" :key="index">
				<view class="img">
					<image :src="item.image"></image>
				</view>
				<view class="title">
					<text>{{item.store_name}}</text>
					<text>{{item.price}}元</text>
				</view>
				<view class="num">
					<view class="box" @click="reduce(index)">-</view>
					<input type="type" v-model="item.num" />
					<view class="box" @click="add(index)">+</view>
				</view>
			</view>
			<view class="express" @click="openCoupon">
				<view>优惠券</view>	
				<view class="images">
					<text style="color: #8b8b8b; ">{{coupon==''? '请选择优惠券':coupon.coupon_price}}</text>
					<image src="../../static/image/you.png"></image>
				</view>
					
			</view>
			<view class="express">
				<view>配送方式</view>
				<picker @change="PickerChange" :value="index" :range="picker">
					<view class="picker">
						{{picker[index]}}
						<image src="../../static/image/you.png"></image>
					</view>
				</picker>
			</view>
			<view class="tarea">
				<textarea v-model="mark" placeholder="如有特殊要求，请给技工备注留言"></textarea>
			</view>


		</view>

		<view class="price">
			<view class="case">
				<text>安装服务费</text>
				<text>{{chooseStore.installfee}}元</text>
			</view>
			<view class="case">
				<text>商品价格</text>
				<text>{{chooseStore.price}}元</text>
			</view>
			<view class="case">
				<text>优惠金额</text>
				<text>{{coupon==''? '0':coupon.coupon_price}}元</text>
			</view>
		</view>


		<view class="kong"></view>


		<!-- 底部付款 -->
		<view class="bottom">
			<view class="number">
				待支付<text>{{total}}</text>
			</view>
			<view class="submit" @click="submit">立即购买</view>
		</view>



		<!-- 选择优惠券弹框 -->
		<view class="location" v-if="showCoupon" @click="closeCoupon">
			<view class="loca" @click.stop="stop">
				<view class="loca-top">
					<text @click="closeCoupon">取消</text>
					<text @click="affirmCoupon">确认</text>
				</view>
				<view class="loca-cont">

					<scroll-view scroll-y="true" class="scroll-y">

						<view class="coupon" v-for="(item,index) in arrcoupon" :key="index">
							<view class="coupon-top">
								<text>¥</text>
								<text>{{item.coupon_price}}</text>
								<view class="name">
									{{item.coupon_title}}
								</view>
							</view>
							<view class="time">
								<text>有效期：{{item._add_time}}至{{item._end_time}}</text>
							</view>
							<view class="uses" v-if="item.is_select==false">不可使用</view>
							<view class="use" v-else @click="use(item)">去使用</view>

						</view>

					</scroll-view>

				</view>
			</view>
		</view>



		<!-- 选择地址弹框 -->
		<view class="location" v-if="showSite" @click="closeSite">
			<view class="loca" @click.stop="stop">
				<view class="loca-top">
					<text @click="closeSite">取消</text>
					<text @click="affirm">确认</text>
				</view>
				<view class="loca-cont">

					<scroll-view scroll-y="true" class="scroll-y">
						<radio-group style="width: 100%;" @change="radioChange">
							<view class="box" :class="{borders:siteId==item.id}" @click="chooseSite(item)" v-for="(item,index) in arrsite"
							 :key="index">
								<text>{{item.province}}{{item.city}}{{item.district}},{{item.detail}}</text>
								<text>联系人：{{item.real_name}}</text>
								<text>电话：{{item.phone}}</text>
								<view class="checked">
									<radio color="#FF8A00" style="transform: scale(0.7);" :value="String(item.id)" :checked="item.is_default==1"></radio>
									<text>设为默认地址</text>
								</view>
							</view>
						</radio-group>
						<view class="add" @click="addSite">添加新地址</view>
					</scroll-view>

				</view>
			</view>
		</view>

	</view>
</template>

<script>
	import {
		getAttr,
		getSuo,
		getAddress,
		getDefault,
		defaultSet,
		getSuoDetail,
		suoAddCar,
		suoConfirm,
		suoCreate,
		getCouponUser
	} from '../../api/api.js'
	import hTimeAlert from "@/components/h-time-alert/h-time-alert.vue";
	export default {
		components: {
			hTimeAlert
		},
		data() {
			return {
				// 服务时间
				isShow: false,
				maskHide: false,
				closeBtn: false,
				rangeType: false,
				time: '',
				num: 1,
				showSite: false,
				// 优惠券
				arrcoupon: [],
				coupon: '',
				showCoupon: false, //优惠券弹框
				siteId: 0,
				address: "",
				arrsite: [],
				arrstore: '',
				chooseStore:'',
				total: 100,
				price: 100,
				index: 0,
				picker: ['快递/自提', '上门安装', ],
				type: "快递/自提",
				mark: '', //备注
				id: '',

				// 锁图片
				imgWc: [],
				wcUrl: '',
				imgNc: [],
				ncUrl: '',
				imgCm: [],
				cmUrl: ''
			}
		},
		onLoad(option) {
			console.log(option)
			this.id=option.id

		},
		onShow() {

			this.getsite();
			this.getdefault();
			this.getsuoDetail();
			this.getcoupon();
			this.getSuoList();
		},
		methods: {
			// 服务时间选择
			showMask() {
				this.isShow = true;
				console.log(this.isShow);
			},

			// 获取锁列表
			getSuoList() {
				getSuo({}).then(res => {
					console.log("锁列表", res)
					this.arrstore = res.data.data
					for(var i=0;i<this.arrstore.length;i++){
						if(this.id==this.arrstore[i].id){
							this.arrstore[i].num=1
						}
					}
				})
			},
			// 获取锁详情
			getsuoDetail() {
				let self=this
				getSuoDetail({
					id: this.id
				}).then(res => {
					console.log(res)
					this.chooseStore = res.data.data
					self.count();
				})
			},

			// 获取地址列表
			getsite() {
				getAddress({}).then(res => {
					// console.log(res)
					this.arrsite = res.data.data
				})
			},
			
			// 计算总价
			count(){
				if(this.coupon==''){
					this.total = parseInt(this.chooseStore.price) + parseInt(this.chooseStore.installfee)
				}else{
					this.total = parseInt(this.chooseStore.juanhou_price) + parseInt(this.chooseStore.installfee)
				}
				
			},

			// 获取默认地址
			getdefault() {
				getDefault({}).then(res => {
					// console.log(res)
					this.address = res.data.data
				})

			},

			// 设为默认
			radioChange(e) {
				// console.log(e)
				var id = e.detail.value
				defaultSet({
					id: id
				}).then(res => {
					// console.log(res)
				})
			},
			// 添加新地址
			addSite() {
				uni.navigateTo({
					url: "../../my/pages/address/addSite/addSite"
				})
			},



			handelClose(data) {
				this.time = data.date
				this.isShow = false;

				console.log(data.date);
			},




			//外侧锁正面照
			ChooseZgzImage() {
				uni.chooseImage({
					count: 4, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					success: (res) => {
						if (this.imgWc.length != 0) {
							this.imgWc = this.imgWc.concat(res.tempFilePaths)
						} else {
							this.imgWc = res.tempFilePaths
						}
						uni.uploadFile({
							url: 'https://sddj.chengzhangxiu.com/api/upload/images',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (res) => {
								console.log(res)
								let analysisImg = JSON.parse(res.data)
								console.log(analysisImg)
								this.wcUrl = analysisImg.data
								console.log(this.wcUrl)
							}
						})
					}
				});
			},

			DelZgzImg(e) {
				uni.showModal({
					title: '删除',
					content: '确定要删除这张照片吗？',
					cancelText: '取消',
					confirmText: '确定',
					success: res => {
						if (res.confirm) {
							this.imgWc.splice(e.currentTarget.dataset.index, 1)
						}
					}
				})
			},

			//内侧锁正面照
			ChooseNcImage() {
				uni.chooseImage({
					count: 4, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					success: (res) => {
						if (this.imgNc.length != 0) {
							this.imgNc = this.imgNc.concat(res.tempFilePaths)
						} else {
							this.imgNc = res.tempFilePaths
						}
						uni.uploadFile({
							url: 'https://sddj.chengzhangxiu.com/api/upload/images',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (res) => {
								console.log(res)
								let analysisImg = JSON.parse(res.data)
								console.log(analysisImg)
								this.ncUrl = analysisImg.data
								console.log(this.ncUrl)
							}
						})
					}
				});
			},

			DelNcImg(e) {
				uni.showModal({
					title: '删除',
					content: '确定要删除这张照片吗？',
					cancelText: '取消',
					confirmText: '确定',
					success: res => {
						if (res.confirm) {
							this.imgNc.splice(e.currentTarget.dataset.index, 1)
						}
					}
				})
			},


			//侧面锁体照
			ChooseCmImage() {
				uni.chooseImage({
					count: 4, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					success: (res) => {
						if (this.imgCm.length != 0) {
							this.imgCm = this.imgCm.concat(res.tempFilePaths)
						} else {
							this.imgCm = res.tempFilePaths
						}
						uni.uploadFile({
							url: 'https://sddj.chengzhangxiu.com/api/upload/images',
							filePath: res.tempFilePaths[0],
							name: 'file',
							success: (res) => {
								console.log(res)
								let analysisImg = JSON.parse(res.data)
								console.log(analysisImg)
								this.cmUrl = analysisImg.data
								console.log(this.cmUrl)
							}
						})
					}
				});
			},

			DelCmImg(e) {
				uni.showModal({
					title: '删除',
					content: '确定要删除这张照片吗？',
					cancelText: '取消',
					confirmText: '确定',
					success: res => {
						if (res.confirm) {
							this.imgCm.splice(e.currentTarget.dataset.index, 1)
						}
					}
				})
			},










			// 优惠券选择弹框
			closeCoupon() {
				this.showCoupon = false
			},
			openCoupon() {
				this.showCoupon = true
			},
			getcoupon() {
				let self = this
				getCouponUser({
					type: 1
				}).then(res => {
					console.log(res)
					self.arrcoupon = res.data.data
					
				})
			},
			use(item) {
				for (var i = 0; i < this.arrcoupon.length; i++) {
					if (item.id == this.arrcoupon[i].id) {
						this.coupon = this.arrcoupon[i]
					}
				}
				this.showCoupon = false
				this.total = parseInt(this.chooseStore.juanhou_price) + parseInt(this.chooseStore.installfee)

			},



			// 地址选择弹框
			closeSite() {
				this.showSite = false
			},
			openSite() {
				this.showSite = true
			},
			stop() {},
			chooseSite(item) {
				// console.log(item)
				for (var i = 0; i < this.arrsite.length; i++) {
					if (item.id == this.arrsite[i].id) {
						this.siteId = this.arrsite[i].id;
						// this.address=this.arrsite[i]
						// console.log(this.siteId)
					}
				}
			},
			// 选择地址确认
			affirm() {
				for (var i = 0; i < this.arrsite.length; i++) {
					if (this.siteId == this.arrsite[i].id) {
						this.address = this.arrsite[i]
					}
				}
				this.closeSite();
			},

			//减号操作
			reduce(index) {
				console.log(index)

				var numb = parseInt(this.arrstore[index].num)
				if (numb > 1) {
					numb = numb - 1
					this.arrstore[index].num = numb;
				} else {
					uni.showToast({
						title: "最少选择一个",
						duration: 2000,
						icon: "none"
					})
				}
				// console.log(this.arrstore)
			},

			//加号操作
			add(index) {
				
				let self=this
				var nums = parseInt(this.arrstore[index].num)

				for(var i=0;i<this.arrstore.length;i++){
						this.arrstore[i].num=0
						if(nums<1){
							this.arrstore[index].num=1;
							this.chooseStore=this.arrstore[index]
							self.count();
						}else{
							uni.showToast({
								title:"最多选择一个",
								duration:1500,
								icon:"none"
							})
							this.arrstore[index].num=1
						}
							
					}
				
			},

			// 快递
			PickerChange(e) {

				this.index = e.detail.value
			},




			submit() {
				uni.showLoading({
					title: "正在创建订单",
					mask: true
				})
				let self = this;
				
				for(var i=0;i<self.arrstore.length;i++){
					if(self.arrstore[i].num==1){
						self.chooseStore=self.arrstore[i]
					}
				}
				
				
				suoAddCar({
					productId: self.chooseStore.id,
					cartNum: 1,
					uniqueId: self.chooseStore.info.unique
				}).then(res => {

					uni.hideLoading();
					let cartid = res.data.data.cartId

					self.submitOrder(cartid)
				})



			},
			submitOrder(cartid) {
				let self = this
				console.log(cartid)
				suoConfirm({
					cartId: cartid
				}).then(res => {

					console.log(res)
					let orderKey = res.data.data.orderKey
					self.setIndent(orderKey)
				})
			},

			setIndent(orderKey) {
				uni.showLoading({
					title: "正在确认订单",
					mask: true
				})
				let self = this
				suoCreate({
					key: orderKey,
					addressId: self.address.id,
					payType: "weixin",
					mark: self.mark,
					from: "routine",
					couponId: self.coupon.id,
					fuwu_time: self.time,
					litpic1: self.wcUrl,
					litpic2: self.ncUrl,
					litpic3: self.cmUrl
				}).then(res => {
					uni.hideLoading();
					console.log(res)
					uni.showToast({
						title: res.data.msg,
						duration: 1500,
						icon: "none"
					})
					if (res.data.status == 200) {
						setTimeout(function() {
							let orderId = res.data.data.result.orderId
							uni.navigateTo({
								url: "../zffs/zffs?orderId=" + orderId
							})
						}, 1500);

					}
				})
			}

		}
	}
</script>

<style scoped>
	@import './qrdd2.css';
</style>
