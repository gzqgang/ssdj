<template>
	<!-- 评价 -->
	<view>
		<view class="box">
			<view class="shop">
				<view class="image">
					<image :src="imgurl+'zhuangsuo.png'" ></image>
				</view>
				<view class="title">
					<view class="name">换锁</view>
				</view>	
			</view>
			<!-- 商品评价 -->
			<view class="appraise">
				<view class="case" @click="haoping">
					<image v-if="appraise==1" src="../../static/icon/hao1.png"></image>
					<image v-if="appraise!=1"  src="../../static/icon/hao2.png"></image>
					<text :class="{choose:appraise==1}">好评</text>
				</view>
				<view class="case" @click="zhongping">
					<image v-if="appraise==2" src="../../static/icon/cha1.png"></image>
					<image v-if="appraise!=2"  src="../../static/icon/cha2.png"></image>
					<text :class="{choose:appraise==2}">中评</text>
				</view>
				<view class="case" @click="chaping">
					<image v-if="appraise==3" src="../../static/icon/cha1.png"></image>
					<image v-if="appraise!=3"  src="../../static/icon/cha2.png"></image>
					<text :class="{choose:appraise==3}">差评</text>
				</view>
			</view>
			<view class="content">
				<textarea placeholder="说点什么吧..."></textarea>
				<view class="img">
					<view class="picture" v-for="(item,index) in imgList" :key="index" :data-url="imgList[index]">
						<image :src="imgList[index]" mode="aspectFill"></image>
						<view class="del bg-red" @tap.stop="DelImg" :data-index="index">
							<text class='cuIcon-close'></text>
						</view>
					</view>
					<view class="solid" @tap="ChooseImage" v-if="imgList.length<1">
						<text class='cuIcon-cameraadd'></text>
					</view>
					<text class="remark">1.点击左侧从业资格证</text>
					<text class="hint">如何获取从业资格证？</text>
				</view>
			</view>
		</view>
		<view class="box">
			<view class="score">服务评分</view>
			<li>
				<text>描述相符</text>
				<rate @change="onChange"></rate>
			</li>
			<li>
				<text>服务技术</text>
				<rate @change="onChange"></rate>
			</li>
			<li>
				<text>服务态度</text>
				<rate @change="onChange"></rate>
			</li>
		</view>
		
		<view class="bottom">
			<view class="anonymity">
				<checkbox></checkbox>
				<text>匿名评价</text>
			</view>
			<view class="submit" @click="topjcg">提交评价</view>
		</view>
		
	</view>
</template>

<script>
import rate from '../../components/rate/rate.vue'
	
	export default {
		name: 'evaluate',
		components:{
			rate
		},
		data() {
			return {
				imgurl:getApp().globalData.imgUrl,
				appraise:1,
				imgList: [],
			}
		},
		methods: {
			// 评价
			haoping(){
				this.appraise=1
			},
			zhongping(){
				this.appraise=2
			},
			chaping(){
				this.appraise=3
			},
			
			// 星星1
			onChange(e){
				console.log(e)
			},
			
			ChooseImage() {
				uni.chooseImage({
					count: 4, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					success: (res) => {
						if (this.imgList.length != 0) {
							this.imgList = this.imgList.concat(res.tempFilePaths)
						} else {
							this.imgList = res.tempFilePaths
						}
					}
				});
			},
			
			DelImg(e) {
				uni.showModal({
					title: '删除',
					content: '确定要删除这张照片吗？',
					cancelText: '取消',
					confirmText: '确定',
					success: res => {
						if (res.confirm) {
							this.imgList.splice(e.currentTarget.dataset.index, 1)
						}
					}
				})
			},
		}
	}
</script>

<style scoped>
@import './pj.css';
</style>
