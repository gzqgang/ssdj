<template>
	<!-- 评价成功 -->
	<view>
		<view class="imgs">
			<image src="../../../static/image/pjcg.png"></image>
		</view>
		<view class="title">
			<text>评价成功</text>
			<text>感谢您的评价，十里春风不如您的一句满意,</text>
			<text>我们将继续提供更好的商品~</text>
		</view>
		
		<view class="submit" @click="toindex">返回首页</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			toindex(){
				uni.redirectTo({
					url:"../../index/index"
				})
			}
		}
	}
</script>

<style scoped>
@import './pjcg.css';
</style>
