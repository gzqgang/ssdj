import apiRequest from '../common/request.js'

// 注册
export const postRegister = (prams) => {
    return apiRequest({
        url: '/register',
        method: 'POST',
        data:prams
    })
}

// 登录
export const postLogin = (prams) => {
    return apiRequest({
        url: '/login',
        method: 'POST',
        data:prams
    })
}

//退出
export const getLogout = (prams) => {
    return apiRequest({
        url: '/logout',
        method: 'GET',
        data:prams
    })
}


//首页
export const getIndex = (prams) => {
    return apiRequest({
        url: '/index',
        method: 'GET',
        data:prams
    })
}
// 微信授权
export const wxLogin = (prams) => {
    return apiRequest({
        url: '/wechat/mp_auth',
        method: 'POST',
        data:prams
    })
}

//首页下方服务
export const getIndexSift = (prams) => {
    return apiRequest({
        url: '/index/get_goods',
        method: 'GET',
        data:prams
    })
}


//个人中心
export const getUser = (prams) => {
    return apiRequest({
        url: '/user',
        method: 'GET',
        data:prams
    })
}

// 获取收货地址
export const getAddress = (prams) => {
    return apiRequest({
        url: '/address/list',
        method: 'GET',
        data:prams
    })
}
// 添加或编辑地址
export const postAddress = (prams) => {
    return apiRequest({
        url: '/address/edit',
        method: 'POST',
        data:prams
    })
}

// 获取默认地址
export const getDefault = (prams) => {
    return apiRequest({
        url: '/address/default',
        method: 'GET',
        data:prams
    })
}


// 设为默认地址
export const defaultSet = (prams) => {
    return apiRequest({
        url: '/address/default/set',
        method: 'POST',
        data:prams
    })
}

// 删除地址
export const delSet = (prams) => {
    return apiRequest({
        url: '/address/del',
        method: 'POST',
        data:prams
    })
}
// 获取单条地址
export const getDetail = (prams) => {
    return apiRequest({
        url: '/address/detail',
        method: 'GET',
        data:prams
    })
}


// 获取分类
export const getClassify = (prams) => {
    return apiRequest({
        url: '/category',
        method: 'GET',
        data:prams
    })
}

// 获取商品详情
export const getShopDetail = (prams) => {
    return apiRequest({
        url: '/product/detail',
        method: 'GET',
        data:prams
    })
}


// 添加购物车
export const addShopCar = (prams) => {
    return apiRequest({
        url: '/fuwu_cart/add',
        method: 'POST',
        data:prams
    })
}


// 确认订单
export const affirmOrder = (prams) => {
    return apiRequest({
        url: '/fuwu_order/confirm',
        method: 'POST',
        data:prams
    })
}

// 创建订单
export const setOrder = (prams) => {
    return apiRequest({
        url: '/fuwu_order/create',
        method: 'POST',
        data:prams
    })
}


// 根据唯一标识获取详情
export const getAttr = (prams) => {
    return apiRequest({
        url: '/fuwu_order/attr_value',
        method: 'GET',
        data:prams
    })
}

// 获取订单详情
export const getOrderDetail  = (prams) => {
    return apiRequest({
        url: '/fuwu_order/detail',
        method: 'GET',
        data:prams
    })
}

// 获取订单详情
export const getFuwuDetail = (prams) => {
    return apiRequest({
        url: '/order/detail',
        method: 'GET',
        data:prams
    })
}



// 获取订单列表
export const getOrder = (prams) => {
    return apiRequest({
        url: '/fuwu_order/list',
        method: 'GET',
        data:prams
    })
}


// 生成分享二维码
export const getErweima = (prams) => {
    return apiRequest({
        url: '/spread/erweima',
        method: 'GET',
        data:prams
    })
}

// 获取服务分类
export const getFuwuCategory = (prams) => {
    return apiRequest({
        url: '/fuwu_category',
        method: 'GET',
        data:prams
    })
}

// 申请成为技工
export const postJigong = (prams) => {
    return apiRequest({
        url: '/apply/jigong',
        method: 'POST',
        data:prams
    })
}

// 申请成为合伙人
export const postHhr = (prams) => {
    return apiRequest({
        url: '/apply/chuangke',
        method: 'POST',
        data:prams
    })
}

// 申请创客支付
export const postHhrZf = (prams) => {
    return apiRequest({
        url: '/recharge/chaungke',
        method: 'POST',
        data:prams
    })
}


// 可领取优惠券列表
export const getCoupon = (prams) => {
    return apiRequest({
        url: '/coupons',
        method: 'GET',
        data:prams
    })
}

// 我的优惠券列表
export const getCouponUser = (prams) => {
    return apiRequest({
        url: '/coupons/user',
        method: 'GET',
        data:prams
    })
}



// 领取优惠券
export const postCoupon = (prams) => {
    return apiRequest({
        url: '/coupon/receive/batch',
        method: 'POST',
        data:prams
    })
}

// 获取锁
export const getSuo = (prams) => {
    return apiRequest({
        url: '/suo',
        method: 'GET',
        data:prams
    })
}

// 锁详情
export const getSuoDetail = (prams) => {
    return apiRequest({
        url: '/suo/view',
        method: 'GET',
        data:prams
    })
}

// 锁 购物车 订单 支付
export const suoAddCar = (prams) => {
    return apiRequest({
        url: '/cart/add',
        method: 'POST',
        data:prams
    })
}
export const suoConfirm = (prams) => {
    return apiRequest({
        url: '/order/confirm',
        method: 'POST',
        data:prams
    })
}
export const suoCreate = (prams) => {
    return apiRequest({
        url: '/order/create',
        method: 'POST',
        data:prams
    })
}


// 取消订单
export const postCancel= (prams) => {
    return apiRequest({
        url: '/order/cancel',
        method: 'POST',
        data:prams
    })
}



// 充值额度选择
export const getRecharge = (prams) => {
    return apiRequest({
        url: '/recharge/index',
        method: 'GET',
        data:prams
    })
}

// 充值
export const postChongzhi = (prams) => {
    return apiRequest({
        url: '/recharge/chongzhi',
        method: 'POST',
        data:prams
    })
}


// 提现
export const getMoney = (prams) => {
    return apiRequest({
        url: '/extract/user_money',
        method: 'GET',
        data:prams
    })
}

// 提现
export const postMoney = (prams) => {
    return apiRequest({
        url: '/extract/cash',
        method: 'POST',
        data:prams
    })
}

// 开通会员
export const getVip = (prams) => {
    return apiRequest({
        url: '/recharge/kaitong_vip',
        method: 'POST',
        data:prams
    })
}


// 会员中心
export const getMember = (prams) => {
    return apiRequest({
        url: '/recharge/huiyuan_zhognxin',
        method: 'GET',
        data:prams
    })
}

// 购买记录
export const getVipRecord = (prams) => {
    return apiRequest({
        url: '/recharge/jilu',
        method: 'GET',
        data:prams
    })
}