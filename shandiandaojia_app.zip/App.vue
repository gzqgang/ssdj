<script>
	export default {
		globalData:{
			imgUrl:"https://sddj.chengzhangxiu.com/uploads/sddj/"
		},
		
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
	
</script>

<style>
	/*每个页面公共css */
	@import "colorui/main.css";
	@import "colorui/icon.css";
	page{
		background-color: #f2f2f2;
	}
	uni-swiper .uni-swiper-dots-horizontal{
		left: 45%;
		bottom: 55rpx;
		transform: scale(0.8);
	}
	
	uni-checkbox .uni-checkbox-input {
	      border-radius: 50% !important;
	      color: #ffffff !important;
	    }
	    
	    uni-checkbox .uni-checkbox-input.uni-checkbox-input-checked {
	      border: none !important;
	      background: #FFAA47;
	        border-color: #FFAA47;
	    }
	    
	    uni-checkbox .uni-checkbox-input.uni-checkbox-input-checked::before {
	        width: 20rpx;
	        height: 20rpx;
	        line-height: 20rpx;
	        text-align: center;
	        font-size: 18rpx;
	        color: #fff;
	        background: transparent;
	        transform: translate(-70%, -50%) scale(1);
	        -webkit-transform: translate(-70%, -50%) scale(1);
	    }
	    
	    /* #endif */
	    /* 微信样式 */
	    /* #ifdef APP-PLUS ||MP-WEIXIN */
	    checkbox .wx-checkbox-input {
	      border-radius: 50% !important;
	      color: #ffffff !important;
	    }
	    
	    checkbox .wx-checkbox-input.wx-checkbox-input-checked {
	      color: #fff;
	      background: #FFAA47;
	    }
	    
	    .wx-checkbox-input.wx-checkbox-input-checked {
	      border: none !important;
	    }
</style>
