import {
	baseURL
} from './config.js'

export const apiRequest=(prams)=>{
	let headerDate = {
		"content-type":"application/json ",
		"Authori-zation":'Bearer '+uni.getStorageSync("token")
	}
	return new Promise((reslove, reject) => {
			let url=baseURL+prams.url
	     return uni.request({
	            url:url,
				method: prams.method,
	            data: prams.data,
	            header: headerDate,
	            success: (res) => {
	            	uni.hideLoading()
					reslove(res)
					// console.log(res.data)
					if(res.data.status==410000){
						uni.showToast({
							title:"未获取到用户信息，请登录",
							duration:1500,
							icon:"none"
						})
						setTimeout(function() {
							uni.removeStorage({
								key:"token",
								success:(res)=>{
									
									uni.reLaunch({
										url:"/pages/login/login"
									})
								},
								fail: () => {
									
									uni.reLaunch({
										url:"/pages/login/login"
									})
								}
							})
						}, 1500);
					}
	            },
				   fail: (err) => {
				   	reject(err)
				   }
	        })
	    });
	}
export default apiRequest




