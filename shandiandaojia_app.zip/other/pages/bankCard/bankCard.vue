<template>
	<view>
		<view class="addCard">
			<view class="hint">
				<text>请绑定持卡人本人的银行卡</text>
			</view>
			<view class="addInput">
				<li>
					<text>持卡人</text>
					<input type="text" />
				</li>
				<li>
					<text>银行卡号</text>
					<input type="text" />
				</li>
				<li>
					<text>开户行</text>
					<input type="text" />
				</li>
			</view>
		</view>
		
		<!-- 确定添加 -->
		<view class="submit">确认添加</view>
		<view class="tshi">
			<text>提示：仅支持绑定借计卡（储蓄卡），不支持信用卡</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style scoped>
@import './bankCard';
</style>
