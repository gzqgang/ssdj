<template>
	<view>
		<view class="box"></view>
		<chose-city @selectCity="selectCity" v-if="showCity" @closeModal="closeModal"></chose-city>
	</view>
</template>

<script>
	import choseCity from "@/components/chose-city/chose-city"
	export default {
		components:{
			 choseCity
		},
		data() {
			return {
				showCity:true
			}
		},
		methods: {
			    selectCity(item) {
			            console.log('-您选择的城市-',item)
			            // this.showCity = false
						var site = item.name
						uni.setStorage({
							key:"site",
							data:site
						})
						uni.navigateTo({
							url:"../jgrz/jgrz?site="+site
						})
			        },
			        closeModal() {
			            this.showCity = false
			        },
		}
	}
</script>

<style>


</style>

