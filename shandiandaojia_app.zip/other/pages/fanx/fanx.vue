<template>
	<!-- 申请售后/返修 -->
	<view>
		<view class="step">
			<view class="padding">
				<view class="cu-steps">
					<view class="cu-item" :class="index>arrIndent.state?'':'text-orange'" v-for="(item,index) in basicsList" :key="index">
						{{item.name}}
						<view class="circle"></view>
					</view>
				</view>
			</view>
		</view>
		
		<!-- 进度 -->
		<view class="plan">
			<timeline>
			        <timelineItem leftTime='2020-01-02'>
			            <view class="tripItem">
			                <view class="title">小闪正再审核中，请稍等。 </view>
			                <view class="tips">（也可拨打闪电到家全国热线：952954 转售后专席）</view>
			            </view>
			        </timelineItem>
			        <timelineItem leftTime='2020-01-01'>
			            <view class="tripItem">
			                <view class="title">您的服务申请已提交</view>
			               
			            </view>
			          
			        </timelineItem>
			</timeline>
		</view>
		
		<view class="artisan" v-if="arrIndent.state==0">
			<text class="titles">服务技工</text>
			 <view class="art-name">
				 <text>{{artisan.name}}</text>
				 <text>公号：{{artisan.numb}}</text>
			 </view>
			 <view class="art-img">
				 <image src="../../../static/image/you.png"></image>
			 </view>
		</view>
		
		<view class="choose"  v-if="arrIndent.state==0" @click="openShop">
			<text>选择订单:</text>
			<image src="../../../static/image/you.png"></image>
		</view>
		<view class="box">
			<view class="goods">
				<view class="image">
					<image :src="arrIndent.image_url"></image>
				</view>
				<view class="title">
					<view class="name">

					</view>
					<view class="site">服务地址：{{arrIndent.site}}</view>
					<view class="time">上门时间：{{arrIndent.time}}</view>
					<view class="number"><text>服务人员：{{arrIndent.name}}</text>
						<view class="box2" v-if="arrIndent.status==3">已完成</view>
					</view>
				</view>

			</view>
			<view class="price">
				<view class="case">
					<text>服务金额</text>
					<text>{{arrIndent.total}}元</text>
				</view>
				<view class="case">
					<text>夜间交通费</text>
					<text>0元</text>
				</view>
				<view class="case">
					<text>优惠金额</text>
					<text>0元</text>
				</view>
			</view>
		</view>
		<view class="boxs">
			<view class="total">
				<text>实付金额</text>
				<text>{{total}}元</text>
			</view>
			<view class="text">订单信息</view>
			<view class="time">
				<text>订单编号：{{arrIndent.number}}</text>
				<text>交易号：{{arrIndent.serial}}</text>
				<text>创建时间：{{arrIndent.start_time}}</text>
				<text>付款时间：{{arrIndent.end_time}}</text>
			</view>
		</view>
		
		<!-- 问题描述 -->
		<view class="issue" v-if="arrIndent.state==0">
			<textarea placeholder="问题描述..."></textarea>
			
			<view class="cu-form-group">
				<view class="grid col-4 grid-square flex-sub">
					<view class="bg-img" v-for="(item,index) in imgList" :key="index" @tap="ViewImage" :data-url="imgList[index]">
					 <image :src="imgList[index]" mode="aspectFill"></image>
						<view class="cu-tag bg-red" @tap.stop="DelImg" :data-index="index">
							<text class='cuIcon-close'></text>
						</view>
					</view>
					<view class="solids" @tap="ChooseImage" v-if="imgList.length<4">
						<text class='cuIcon-cameraadd'></text>
					</view>
				</view>
			</view>
		</view>

	<view class="submit"  v-if="arrIndent.state==0">提交</view>







	<!-- 选择商品弹框 -->
	<view class="shop" v-if="showShop" @click="closeShop">
		<view class="shop-box" @click.stop="stop">
			<view class="scroll">
				<scroll-view scroll-y="true">
					<view class="goods" v-for="(item,id) in arrshop" :key="id" @click="toxq(item)">
						<view class="image">
							<image :src="item.image_url"></image>
						</view>
						<view class="title">
							<view class="name">
								<view>{{item.name}}</view>
								
							</view>
							<view class="site">服务地址：{{item.site}}</view>
							<view class="time">上门时间：{{item.time}}</view>
							<view class="numb">订单编号：{{item.number}}</view>
						</view>
						<view class="bottom">
							<view class="serial">交易流水号：{{item.serial}}</view>
							<view class="btn">
								
								<view class="box3">选择</view>
							</view>
						</view>
					</view>
				</scroll-view>
			</view>
		</view>
	</view>
	</view>
</template>

<script>
	import timeline from '../../../components/chenbin-timeline/timeLine.vue'
	import timelineItem from '../../../components/chenbin-timeline/timelineItem.vue'
	export default {
	        components:{
	            timeline,
	            timelineItem
	        },
		data() {
			return {
				artisan:{id:1,name:"闪电先生",numb:"9527"},//服务技工
				showShop:false,
				basicsList: [{
					cuIcon: 'usefullfill',
					name: '申请售后'
				}, {
					cuIcon: 'radioboxfill',
					name: '闪电审核'
				}, {
					cuIcon: 'roundclosefill',
					name: '技工回访'
				}, {
					cuIcon: 'roundcheckfill',
					name: '已完成'
				}, ],
				basics: 2,
				total: 100,
				arrIndent: {
					id: 1,
					name: "闪电先生",
					text: "换锁",
					image_url: "../../../static/image/zhuangsuo.png",
					site: "山东省济南市历下区山大南路",
					time: "2021-05-25 22:00",
					number: "123456789",
					serial: "3321654987",
					total: 100,
					sale: 0,
					tra_price: 0,
					start_time: "2021-05-25 22:00",
					end_time: "2021-05-25 22:00",
					status: 3,
					state:0
				},
				imgList: [],
				arrshop:[
					{
						id: 1,
						name: "闪电先生",
						text: "换锁",
						image_url: "../../static/image/zhuangsuo.png",
						site: "山东省济南市历下区山大南路",
						time: "2021-05-25 22:00",
						number: "123456789",
						serial: "3321654987",
						total: 100,
						sale: 0,
						tra_price: 0,
						start_time: "2021-05-25 22:00",
						end_time: "2021-05-25 22:00",
						status: 3,
						state:0
					},
					{
						id: 2,
						name: "闪电先生",
						text: "换锁",
						image_url: "../../static/image/zhuangsuo.png",
						site: "山东省济南市历下区山大南路",
						time: "2021-05-25 22:00",
						number: "123456789",
						serial: "3321654987",
						total: 100,
						sale: 0,
						tra_price: 0,
						start_time: "2021-05-25 22:00",
						end_time: "2021-05-25 22:00",
						status: 3,
						state:0
					}
						
				]
			}
		},
		methods: {
			openShop(){
				this.showShop=true
			},
			closeShop(){
				this.showShop=false
			},
			stop(){},
			
			
			ChooseImage() {
				uni.chooseImage({
					count: 4, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album'], //从相册选择
					success: (res) => {
						if (this.imgList.length != 0) {
							this.imgList = this.imgList.concat(res.tempFilePaths)
						} else {
							this.imgList = res.tempFilePaths
						}
					}
				});
			},
			ViewImage(e) {
				uni.previewImage({
					urls: this.imgList,
					current: e.currentTarget.dataset.url
				});
			},
			DelImg(e) {
				uni.showModal({
					title: '删除',
					content: '确定要删除这张照片吗？',
					cancelText: '取消',
					confirmText: '确定',
					success: res => {
						if (res.confirm) {
							this.imgList.splice(e.currentTarget.dataset.index, 1)
						}
					}
				})
			},
			
			
		}
	}
</script>

<style scoped>
	@import './fanx.css';
</style>
