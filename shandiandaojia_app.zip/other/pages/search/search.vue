<template>
	<view>
		<!-- 搜索框 -->
		<view class="search">
			<image class="zuo" src="../../../static/img/zuo1.png"  @click="toback"></image>
			<view class="search-form">
				<image src="../../../static/img/sousuo.png"></image>
				<input :adjust-position="false" type="text" placeholder="" confirm-type="search" v-model="arrgoods"></input>
				<image src="../../../static/img/yuyin.png"></image>
			</view>
				<view class="title" @click="seek(arrgoods)">搜索</view>
		</view>
		<!-- 历史记录 -->
		<view v-if="ifhistory">
			<view class="history">
				<view class="history-history">历史记录</view>
				<view class="del" @click="remove">清除</view>
			</view>
			<view class="discover">
				<view class="boxx" v-for="(item,id) in setdata" :key="id">
					<view class="content" @click="record(item)">
					{{item}}
					</view>
				</view>
			</view>
		</view>
		<!-- 热门搜索 -->
		<view>
			<view class="history">
				<view class="history-history">热门搜索</view>
			</view>
			<view class="discover">
				<view class="boxx" v-for="(item,id) in hotSearch" :key="id">
					<view class="content" @click="record(item)">
					{{item}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				arrgoods: '',
				ifhistory: false,
				setdata: [],
				hotSearch:["保洁","按摩","采耳","开锁","换锁"]
			}
		},
		onShow() {
		this.setStorage()
		
		
		},
		methods: {
			// 返回
			toback(){
				uni.navigateBack({
					delta:1
				})
			},
			//搜索
			seek(arrgoods) {
				arrgoods = arrgoods === false ? this.arrgoods : arrgoods;
				this.arrgoods = arrgoods;
				if (this.arrgoods != '') {
					this.getStorage(this.arrgoods)
					// uni.navigateTo({
					// 	url: "./shopSear?arrgoods=" + arrgoods
					// })
				}
			},
			//历史记录
			record(item) {
				console.log(item)
				this.arrgoods=item
				this.seek(item)
			},
			// 存储搜索历史到本地缓存
			getStorage(searchkey) {
				let searray = uni.getStorageSync('srarch_key') || []
				searray.unshift(searchkey)
				uni.setStorageSync('srarch_key', searray)
			},
			setStorage() {
				let setdata = uni.getStorageSync('srarch_key')
				//数组去掉重复
				let setdataarr = Array.from(new Set(setdata))
				
				if (setdataarr.length === 0) {
					this.ifhistory = false
				} else {
					this.setdata = setdataarr
					this.ifhistory = true
				}
			},
			// 清除
			remove() {
				uni.removeStorageSync('srarch_key')
				this.setStorage()
			}
		
		
		
		
		}
	}
</script>

<style scoped>
@import './search.css';
</style>
