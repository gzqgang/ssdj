<template>
	<!-- 支付成功 -->
	<view>
		<view class="xq2">
			<view class="pay">
				<text>支付成功</text>
				<text>感谢您的购买</text>
				<view></view>
			</view>
			<view class="content">
				<view class="good">
					<view class="image">
						<image :src="arrIndent.image_url"></image>
					</view>
					<view class="title">
						<view class="name">{{arrIndent.text}}</view>
						<view class="site">服务地址：{{arrIndent.site}}</view>
						<view class="time">上门时间：{{arrIndent.time}}</view>
					</view>
				</view>
				<view class="prices">
					<view class="case">
						<text>服务金额</text>
						<text>{{arrIndent.total}}元</text>
					</view>
					<view class="case">
						<text>夜间交通费</text>
						<text>0元</text>
					</view>
					<view class="case">
						<text>优惠金额</text>
						<text>0元</text>
					</view>
				</view>
				
				<view class="boxx">
					<view class="total">
						<text>实付金额</text>
						<text>{{total}}元</text>
					</view>
					<view class="text">订单信息</view>
					<view class="time">
						<text>订单编号：{{arrIndent.number}}</text>
						<text>付款时间：{{arrIndent.end_time}}</text>
						<text>支付方式：{{arrIndent.type}}</text>
					</view>
				</view>
			</view>
		<view class="payment">
			<view>查看订单</view>
			<view>返回首页</view>
		</view>
		
		<view class="issue">
			<view class="issue-top">
				<text>问题中心</text>
				<view></view>
				<text>在线客服</text>
			</view>
			<text class="issue-bottom" >积分更新期间参与用户邀请好友会额外获得一</text>
		</view>
		
		<!-- 推荐 -->
		<view class="rec">
			<view class="rec-top"><text>为您推荐</text></view>
			
			<view class="recs">
				<view class="mend" v-for="(item,index) in arrNavCont" :key="index">
					<view class="image">
						<image :src="item.image"></image>
					</view>
					<view class="title">
						<text class="name">{{item.name}}</text>
						<view class="price">
							<text>￥</text>
							<text>{{item.price}}起</text>
						</view>
					</view>
				</view>
			</view>
		</view>
		
		
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				arrIndent:{
						id: 1,
						name: "闪电先生",
						text:"换锁",
						image_url: getApp().globalData.imgUrl+'zhuangsuo.png',
						site: "山东省济南市历下区山大南路",
						time: "2021-05-25 22:00",
						number: "123456789",
						serial: "3321654987",
						total:100,
						sale:0,
						tra_price:0,
						type:"微信支付",
						start_time:"2021-05-25 22:00",
						end_time:"2021-05-25 22:00",
						status: 4
				},
				total:100,
				arrNavCont:[
					{
						id:1,
						name:"空调清洗维修",
						price:30,
						image: "../../static/index/kongtiao.png"
					},{
						id:2,
						name:"空调清洗维修",
						price:30,
						image: "../../static/index/kongtiao.png"
					}
				]
			}
		},
		methods: {
			
		}
	}
</script>

<style scoped>
@import './zfcg.css';
</style>
